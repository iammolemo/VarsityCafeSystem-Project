﻿
namespace Varsity_cafe_system
{
    partial class OrdersPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.homeBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.changeBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.menuLbl = new System.Windows.Forms.Label();
            this.maintainGrp = new System.Windows.Forms.GroupBox();
            this.orderGrid = new System.Windows.Forms.DataGridView();
            this.changeTxtBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.maintainGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Red;
            this.homeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.Location = new System.Drawing.Point(780, 522);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(148, 44);
            this.homeBtn.TabIndex = 17;
            this.homeBtn.Text = "GO TO HOME PAGE";
            this.homeBtn.UseVisualStyleBackColor = false;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Red;
            this.deleteBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.Location = new System.Drawing.Point(63, 283);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(152, 44);
            this.deleteBtn.TabIndex = 13;
            this.deleteBtn.Text = "DELETE AN ORDER";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // changeBtn
            // 
            this.changeBtn.BackColor = System.Drawing.Color.Red;
            this.changeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeBtn.Location = new System.Drawing.Point(63, 163);
            this.changeBtn.Name = "changeBtn";
            this.changeBtn.Size = new System.Drawing.Size(152, 44);
            this.changeBtn.TabIndex = 12;
            this.changeBtn.Text = "MODIFY AN ORDER";
            this.changeBtn.UseVisualStyleBackColor = false;
            this.changeBtn.Click += new System.EventHandler(this.changeBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(21, 522);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(164, 44);
            this.backBtn.TabIndex = 16;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // menuLbl
            // 
            this.menuLbl.AutoSize = true;
            this.menuLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuLbl.Location = new System.Drawing.Point(352, 26);
            this.menuLbl.Name = "menuLbl";
            this.menuLbl.Size = new System.Drawing.Size(222, 29);
            this.menuLbl.TabIndex = 15;
            this.menuLbl.Text = "MAINTAIN ORDERS";
            // 
            // maintainGrp
            // 
            this.maintainGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.maintainGrp.Controls.Add(this.label1);
            this.maintainGrp.Controls.Add(this.changeTxtBox);
            this.maintainGrp.Controls.Add(this.orderGrid);
            this.maintainGrp.Controls.Add(this.deleteBtn);
            this.maintainGrp.Controls.Add(this.changeBtn);
            this.maintainGrp.Location = new System.Drawing.Point(6, 58);
            this.maintainGrp.Name = "maintainGrp";
            this.maintainGrp.Size = new System.Drawing.Size(938, 442);
            this.maintainGrp.TabIndex = 14;
            this.maintainGrp.TabStop = false;
            this.maintainGrp.Enter += new System.EventHandler(this.maintainGrp_Enter);
            // 
            // orderGrid
            // 
            this.orderGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.orderGrid.Location = new System.Drawing.Point(258, 62);
            this.orderGrid.Name = "orderGrid";
            this.orderGrid.Size = new System.Drawing.Size(664, 359);
            this.orderGrid.TabIndex = 15;
            // 
            // changeTxtBox
            // 
            this.changeTxtBox.Location = new System.Drawing.Point(115, 240);
            this.changeTxtBox.Name = "changeTxtBox";
            this.changeTxtBox.Size = new System.Drawing.Size(100, 20);
            this.changeTxtBox.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Change:";
            // 
            // OrdersPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 588);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.menuLbl);
            this.Controls.Add(this.maintainGrp);
            this.Name = "OrdersPage";
            this.Text = "OrdersPage";
            this.Load += new System.EventHandler(this.OrdersPage_Load);
            this.maintainGrp.ResumeLayout(false);
            this.maintainGrp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button homeBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button changeBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label menuLbl;
        private System.Windows.Forms.GroupBox maintainGrp;
        private System.Windows.Forms.DataGridView orderGrid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox changeTxtBox;
    }
}