﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class mainMenu : Form
    {
        public mainMenu()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            breakfastMenu breakk= new breakfastMenu();
            breakk.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            russianRollMenu roll = new russianRollMenu();
            roll.ShowDialog();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            this.Hide();
            burgersMenu burger = new burgersMenu();
            burger.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            toastiesMenu toast = new toastiesMenu();
            toast.ShowDialog(); 
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            this.Hide();
            wrapQuesadillaMenu wrap = new wrapQuesadillaMenu();
            wrap.ShowDialog();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Hide();
            saladsMenu salad = new saladsMenu();
            salad.ShowDialog();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Hide();
            chipsMenu chips = new chipsMenu();
            chips.ShowDialog();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            this.Hide();
            beveragesMenu beverages = new beveragesMenu();
            beverages.ShowDialog();

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.Hide();
            nachosMenu nacho = new nachosMenu();
            nacho.ShowDialog(); 
        }

        
        private void burgerPicBox(object sender, EventArgs e)
        {
                this.Hide();
                burgersMenu burger = new burgersMenu();
                burger.ShowDialog();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            homePage home = new homePage ();
            home.ShowDialog();
        }
    }
}
