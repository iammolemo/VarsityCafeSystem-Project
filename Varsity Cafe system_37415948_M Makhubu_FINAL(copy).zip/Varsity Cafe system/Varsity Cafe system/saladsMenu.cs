﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class saladsMenu : Form
    {
        public void ShowQuantityPage()// Function that hide a current page and shows the quantity page
        {
            this.Hide();
            quantityPage quantity = new quantityPage();
            quantity.ShowDialog();
        }
        public void ShowMainMenu()// Function that hide a current page and shows the main menu page
        {
            this.Hide();
            mainMenu main = new mainMenu();
            main.ShowDialog();
        }
        public saladsMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ShowMainMenu();
        }

        private void chickenBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void varsityBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void crispChickenBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void pepadewBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }
    }
}
