USE VarsityCafeDB
GO


CREATE TABLE EMPLOYEE
(
	Empl_ID int IDENTITY(1,1) PRIMARY KEY,
	Empl_FName varchar(30),
	Empl_LName varchar(30),
	Empl_Email_Address varchar(30),
	Empl_CellNum varchar(10),
	Empl_Username varchar(30),
	Empl_Password varchar(10)
	
);

CREATE TABLE MENU
(
	Menu_ID int IDENTITY(1,1) PRIMARY KEY,
	Empl_ID int FOREIGN KEY REFERENCES EMPLOYEE(Empl_ID),
	Availabilty bit
);

CREATE TABLE FOOD_ITEM
(
	Food_Item_ID int IDENTITY(1,1) PRIMARY KEY,
	Food_Item_Name varchar(30),
	Food_Item_Quantity int,
	Unit_Price money,
	Menu_ID int FOREIGN KEY REFERENCES MENU(Menu_ID)

);

CREATE TABLE ORDERS
(
	Order_ID int IDENTITY(1,1) PRIMARY KEY,
	Empl_ID int FOREIGN KEY REFERENCES EMPLOYEE(Empl_ID),
	Food_Item_ID int FOREIGN KEY REFERENCES FOOD_ITEM(Food_Item_ID),
	Order_Date date,
	Order_Time time
);

CREATE TABLE PAYMENT
(
	Payment_ID int IDENTITY(1,1) PRIMARY KEY,
	Order_ID int FOREIGN KEY REFERENCES ORDERS(Order_ID),
	Payment_Date date,
	Payment_Time time,
	Amount money,
	Payment_Type varchar(10)
);