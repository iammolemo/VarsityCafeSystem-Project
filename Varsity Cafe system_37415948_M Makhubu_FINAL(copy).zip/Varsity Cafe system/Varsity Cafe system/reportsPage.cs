﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Varsity_cafe_system
{
    public partial class reportsPage : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        DataSet ds;
        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
        public reportsPage()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintainRequestPage maintain = new maintainRequestPage();
            maintain.ShowDialog();
        }

        private void homeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            homePage home = new homePage();
            home.ShowDialog();
        }

        private void reportsComb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(reportsComb.SelectedIndex==0)
            {
                con = new SqlConnection(conString);
                con.Open();
                string sql = "SELECT * FROM EMPLOYEE";
                cmd = new SqlCommand(sql, con);
                adap = new SqlDataAdapter(cmd);
                ds = new DataSet();
                adap.Fill(ds, "EMPLOYEE");
                reportsGrid.DataSource = ds.Tables["EMPLOYEE"].DefaultView;
                con.Close();
            }
            else if(reportsComb.SelectedIndex==1)
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                string sql = "SELECT * FROM ORDERS";
                cmd = new SqlCommand(sql, con);
                adap = new SqlDataAdapter(cmd);
                ds = new DataSet();
                adap.Fill(ds, "ORDERS");
                reportsGrid.DataSource = ds.Tables["ORDERS"].DefaultView;
                con.Close();
            }
        }

        private void maintainGrp_Enter(object sender, EventArgs e)
        {

        }

        private void searchTxtBox_TextChanged(object sender, EventArgs e)
        {
            if (reportsComb.SelectedIndex == 0)
            {
                con = new SqlConnection(conString);
                con.Open();
                string sql = $"SELECT * FROM EMPLOYEE WHERE Empl_FName LIKE '{searchTxtBox.Text}%'";
                cmd = new SqlCommand(sql, con);
                adap = new SqlDataAdapter(cmd);
                ds = new DataSet();
                adap.Fill(ds, "EMPLOYEE");
                reportsComb.DataSource = ds.Tables["EMPLOYEE"].DefaultView;
                con.Close();
            }
            else if(reportsComb.SelectedIndex == 1)
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                string sql = $"SELECT * FROM Food_Item_Name WHERE  LIKE '{searchTxtBox.Text}%'";
                cmd = new SqlCommand(sql, con);
                adap = new SqlDataAdapter(cmd);
                ds = new DataSet();
                adap.Fill(ds, "Food_Item_Name");
                reportsGrid.DataSource = ds.Tables["Food_Item_Name"].DefaultView;
                con.Close();
            }
                     
        }
    }
}
