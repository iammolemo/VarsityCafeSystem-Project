﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Varsity_cafe_system
{
    public partial class OrdersPage : Form
    {
        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        DataSet ds;
        public OrdersPage()
        {
            InitializeComponent();
        }

        private void changeBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please note that you can only change the quantitiy for an order");
            changeTxtBox.Visible= true;

            con = new SqlConnection(conString);
            con.Open();
            maintainMenuPage maintain = new maintainMenuPage();

            int rowIndex = orderGrid.CurrentCell.RowIndex;
            string sql = $"UPDATE ORDERS SET Orders_Quantity={changeTxtBox.Text} WHERE Order_ID=@index";
            cmd.Parameters.AddWithValue("@change", changeTxtBox.Text);
            cmd.Parameters.AddWithValue("@index", rowIndex);
            cmd = new SqlCommand(sql, con);
        }

        private void maintainGrp_Enter(object sender, EventArgs e)
        {
            
        }

        private void OrdersPage_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            string sql = "SELECT * FROM ORDERS";
            cmd = new SqlCommand(sql, con);
            adap = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adap.Fill(ds, "ORDERS");
            orderGrid.DataSource = ds.Tables["ORDERS"].DefaultView;
            con.Close();
        }

        private void searchTxtBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintainRequestPage request = new maintainRequestPage();
            request.ShowDialog();
        }

        private void homeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            homePage home = new homePage();
            home.ShowDialog();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete the selected record?", "Delete record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int rowIndex = orderGrid.CurrentCell.RowIndex;
                orderGrid.Rows.RemoveAt(rowIndex);
            }
            else
            {
                MessageBox.Show("You have not selected a record to be deleted, Please make sure you do in order to proceed");
            }
        }
    }
}
