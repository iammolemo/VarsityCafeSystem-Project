﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class toastiesMenu : Form
    {
        public void ShowQuantityPage()// Function that hide a current page and shows the quantity page
        {
            this.Hide();
            quantityPage quantity = new quantityPage();
            quantity.ShowDialog();
        }
        public void ShowMainMenu()// Function that hide a current page and shows the main menu page
        {
            this.Hide();
            mainMenu main = new mainMenu();
            main.ShowDialog();
        }
        public toastiesMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ShowMainMenu();
        }

        private void hamBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void minceBtn_Click(object sender, EventArgs e)
        {
                ShowQuantityPage();
        }

        private void biltongBtn_Click(object sender, EventArgs e)
        {
                ShowQuantityPage();
        }

        private void chickenMayoBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void eggBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }
    }
}
