﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class wrapQuesadillaMenu : Form
    {
        public wrapQuesadillaMenu()
        {
            InitializeComponent();
        }
        public void ShowQuantityPage()// Function that hide a current page and shows the quantity page
        {
            this.Hide();
            quantityPage quantity = new quantityPage();
            quantity.ShowDialog();
        }
        public void ShowMainMenu()// Function that hide a current page and shows the main menu page
        {
            this.Hide();
            mainMenu main = new mainMenu();
            main.ShowDialog();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            ShowMainMenu();
        }

        private void sweetChilliBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void avoBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void baconBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }
    }
}
