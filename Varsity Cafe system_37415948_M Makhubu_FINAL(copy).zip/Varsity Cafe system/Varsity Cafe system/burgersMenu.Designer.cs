﻿
namespace Varsity_cafe_system
{
    partial class burgersMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(burgersMenu));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.baconAndCheeseBurgBtn = new System.Windows.Forms.Button();
            this.cheeseBurgBtn = new System.Windows.Forms.Button();
            this.varsityBurgBtn = new System.Windows.Forms.Button();
            this.baconBurgLbl = new System.Windows.Forms.Label();
            this.cheeseBurgLbl = new System.Windows.Forms.Label();
            this.varsityBurgLbl = new System.Windows.Forms.Label();
            this.menuHearderLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.logoPicBx = new System.Windows.Forms.PictureBox();
            this.avoBurgLbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.chickenBtnLbl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.chickenBurgBtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.chickenBurgBtn);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.chickenBtnLbl);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.avoBurgLbl);
            this.groupBox1.Controls.Add(this.baconAndCheeseBurgBtn);
            this.groupBox1.Controls.Add(this.cheeseBurgBtn);
            this.groupBox1.Controls.Add(this.varsityBurgBtn);
            this.groupBox1.Controls.Add(this.baconBurgLbl);
            this.groupBox1.Controls.Add(this.cheeseBurgLbl);
            this.groupBox1.Controls.Add(this.varsityBurgLbl);
            this.groupBox1.Location = new System.Drawing.Point(127, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(533, 399);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // baconAndCheeseBurgBtn
            // 
            this.baconAndCheeseBurgBtn.BackColor = System.Drawing.Color.Red;
            this.baconAndCheeseBurgBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baconAndCheeseBurgBtn.Location = new System.Drawing.Point(349, 162);
            this.baconAndCheeseBurgBtn.Name = "baconAndCheeseBurgBtn";
            this.baconAndCheeseBurgBtn.Size = new System.Drawing.Size(121, 38);
            this.baconAndCheeseBurgBtn.TabIndex = 5;
            this.baconAndCheeseBurgBtn.Text = "R52";
            this.baconAndCheeseBurgBtn.UseVisualStyleBackColor = false;
            this.baconAndCheeseBurgBtn.Click += new System.EventHandler(this.baconAndCheeseBurgBtn_Click);
            // 
            // cheeseBurgBtn
            // 
            this.cheeseBurgBtn.BackColor = System.Drawing.Color.Red;
            this.cheeseBurgBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheeseBurgBtn.Location = new System.Drawing.Point(349, 109);
            this.cheeseBurgBtn.Name = "cheeseBurgBtn";
            this.cheeseBurgBtn.Size = new System.Drawing.Size(121, 35);
            this.cheeseBurgBtn.TabIndex = 4;
            this.cheeseBurgBtn.Text = "R45";
            this.cheeseBurgBtn.UseVisualStyleBackColor = false;
            this.cheeseBurgBtn.Click += new System.EventHandler(this.cheeseBurgBtn_Click);
            // 
            // varsityBurgBtn
            // 
            this.varsityBurgBtn.BackColor = System.Drawing.Color.Red;
            this.varsityBurgBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.varsityBurgBtn.Location = new System.Drawing.Point(349, 61);
            this.varsityBurgBtn.Name = "varsityBurgBtn";
            this.varsityBurgBtn.Size = new System.Drawing.Size(121, 35);
            this.varsityBurgBtn.TabIndex = 3;
            this.varsityBurgBtn.Text = "R45";
            this.varsityBurgBtn.UseVisualStyleBackColor = false;
            this.varsityBurgBtn.Click += new System.EventHandler(this.varsityBurgBtn_Click);
            // 
            // baconBurgLbl
            // 
            this.baconBurgLbl.AutoSize = true;
            this.baconBurgLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baconBurgLbl.Location = new System.Drawing.Point(73, 173);
            this.baconBurgLbl.Name = "baconBurgLbl";
            this.baconBurgLbl.Size = new System.Drawing.Size(181, 16);
            this.baconBurgLbl.TabIndex = 2;
            this.baconBurgLbl.Text = "BACON AND CHEESE BURGER";
            // 
            // cheeseBurgLbl
            // 
            this.cheeseBurgLbl.AutoSize = true;
            this.cheeseBurgLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheeseBurgLbl.Location = new System.Drawing.Point(73, 118);
            this.cheeseBurgLbl.Name = "cheeseBurgLbl";
            this.cheeseBurgLbl.Size = new System.Drawing.Size(109, 16);
            this.cheeseBurgLbl.TabIndex = 1;
            this.cheeseBurgLbl.Text = "CHEESE BURGER";
            // 
            // varsityBurgLbl
            // 
            this.varsityBurgLbl.AutoSize = true;
            this.varsityBurgLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.varsityBurgLbl.Location = new System.Drawing.Point(73, 70);
            this.varsityBurgLbl.Name = "varsityBurgLbl";
            this.varsityBurgLbl.Size = new System.Drawing.Size(110, 16);
            this.varsityBurgLbl.TabIndex = 0;
            this.varsityBurgLbl.Text = "VARSITY BURGER";
            // 
            // menuHearderLbl
            // 
            this.menuHearderLbl.AutoSize = true;
            this.menuHearderLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuHearderLbl.Location = new System.Drawing.Point(253, 22);
            this.menuHearderLbl.Name = "menuHearderLbl";
            this.menuHearderLbl.Size = new System.Drawing.Size(322, 29);
            this.menuHearderLbl.TabIndex = 7;
            this.menuHearderLbl.Text = "BURGERS AND CHIPS MENU";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 470);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(195, 39);
            this.backBtn.TabIndex = 6;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // logoPicBx
            // 
            this.logoPicBx.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBx.Image")));
            this.logoPicBx.Location = new System.Drawing.Point(739, 7);
            this.logoPicBx.Name = "logoPicBx";
            this.logoPicBx.Size = new System.Drawing.Size(70, 44);
            this.logoPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBx.TabIndex = 4;
            this.logoPicBx.TabStop = false;
            // 
            // avoBurgLbl
            // 
            this.avoBurgLbl.AutoSize = true;
            this.avoBurgLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.avoBurgLbl.Location = new System.Drawing.Point(73, 222);
            this.avoBurgLbl.Name = "avoBurgLbl";
            this.avoBurgLbl.Size = new System.Drawing.Size(210, 16);
            this.avoBurgLbl.TabIndex = 6;
            this.avoBurgLbl.Text = "BACON, AVO AND CHEESE BURGER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(73, 274);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "ELEPHANT-FOOT BURGER";
            // 
            // chickenBtnLbl
            // 
            this.chickenBtnLbl.AutoSize = true;
            this.chickenBtnLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenBtnLbl.Location = new System.Drawing.Point(73, 329);
            this.chickenBtnLbl.Name = "chickenBtnLbl";
            this.chickenBtnLbl.Size = new System.Drawing.Size(160, 16);
            this.chickenBtnLbl.TabIndex = 8;
            this.chickenBtnLbl.Text = "CRISPY CHICKEN BURGER";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(349, 211);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 38);
            this.button1.TabIndex = 9;
            this.button1.Text = "R54";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(349, 263);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(121, 38);
            this.button2.TabIndex = 10;
            this.button2.Text = "R64";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // chickenBurgBtn
            // 
            this.chickenBurgBtn.BackColor = System.Drawing.Color.Red;
            this.chickenBurgBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenBurgBtn.Location = new System.Drawing.Point(349, 318);
            this.chickenBurgBtn.Name = "chickenBurgBtn";
            this.chickenBurgBtn.Size = new System.Drawing.Size(121, 38);
            this.chickenBurgBtn.TabIndex = 11;
            this.chickenBurgBtn.Text = "R64";
            this.chickenBurgBtn.UseVisualStyleBackColor = false;
            this.chickenBurgBtn.Click += new System.EventHandler(this.chickenBurgBtn_Click);
            // 
            // burgersMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(821, 521);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuHearderLbl);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.logoPicBx);
            this.Name = "burgersMenu";
            this.Text = "burgersMenu";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button baconAndCheeseBurgBtn;
        private System.Windows.Forms.Button cheeseBurgBtn;
        private System.Windows.Forms.Button varsityBurgBtn;
        private System.Windows.Forms.Label baconBurgLbl;
        private System.Windows.Forms.Label cheeseBurgLbl;
        private System.Windows.Forms.Label varsityBurgLbl;
        private System.Windows.Forms.Label menuHearderLbl;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.PictureBox logoPicBx;
        private System.Windows.Forms.Button chickenBurgBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label chickenBtnLbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label avoBurgLbl;
    }
}