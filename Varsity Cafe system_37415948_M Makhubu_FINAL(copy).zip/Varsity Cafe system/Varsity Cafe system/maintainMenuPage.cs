﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Varsity_cafe_system
{
    public partial class maintainMenuPage : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        DataSet ds;
        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
        public maintainMenuPage()
        {
            InitializeComponent();
        }

        private void LoadAll()
        {
            con = new SqlConnection(conString);
            con.Open();
            string sql = "SELECT * FROM FOOD_ITEM";
            cmd = new SqlCommand(sql, con);
            adap = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adap.Fill(ds, "FOOD_ITEM");
            menuItemGrid.DataSource = ds.Tables["FOOD_ITEM"].DefaultView;
            con.Close();
        }
        private void maintainMenuPage_Load(object sender, EventArgs e)
        {
            LoadAll(); 
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            addGrpBx.Visible = true;
            foodName.Visible = true;
            foodPrice.Visible = true;
            quantTxtBox.Visible= true;
            foodTxt.Visible = true;
            priceTxt.Visible = true;
        }

        private void add_Click(object sender, EventArgs e)
        {
            con.Open();
            string Sql = "INSTERT INTO FOOD_ITEM(Food_Item_Name,Food_Item_Quantity,Unit_Price) VALUES(@name,@quant,@price)";
            cmd = new SqlCommand(Sql, con);
            cmd.Parameters.AddWithValue("@name",foodName.Text);
            cmd.Parameters.AddWithValue("@quant",quantTxtBox.Text);
            cmd.Parameters.AddWithValue("@price",foodPrice.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Menu item has been successfully added.");
            LoadAll();
        }

        private void changeBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            
            string Sql = "UPDATE FOOD_ITEM SET Food_Item_Name=@food,Food_Item_Quantity=@quant,Unit_Price=@price WHERE Food_Item_ID=@index";
            cmd = new SqlCommand(Sql, con);
            con = new SqlConnection(conString);
            con.Open();
            maintainMenuPage maintain = new maintainMenuPage();

            int rowIndex = menuItemGrid.CurrentCell.RowIndex;
            cmd.Parameters.AddWithValue("@food", foodName.Text);
            cmd.Parameters.AddWithValue("@quant", quantTxtBox.Text);
            cmd.Parameters.AddWithValue("@price", foodPrice.Text);
            cmd.Parameters.AddWithValue("@index", rowIndex);
            
            cmd.ExecuteNonQuery();
            con.Close();
            LoadAll();

        }

        private void maskedTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void searchTxtBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void searchTxtBox_TextChanged(object sender, EventArgs e)
        {
            con = new SqlConnection(conString);
            con.Open();
            string sql = $"SELECT * FROM FOOD_ITEM WHERE Food_Item_Name LIKE '{searchTxtBox.Text}%'";
            cmd = new SqlCommand(sql, con);
            adap = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adap.Fill(ds, "FOOD_ITEM");
            menuItemGrid.DataSource = ds.Tables["FOOD_ITEM"].DefaultView;
            con.Close();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintainRequestPage request = new maintainRequestPage();
            request.ShowDialog();
        }

        private void homeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            homePage home = new homePage();
            home.ShowDialog();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete the selected menu item", "Delete record", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int rowIndex =menuItemGrid.CurrentCell.RowIndex;
                menuItemGrid.Rows.RemoveAt(rowIndex);
            }
            else
            {
                MessageBox.Show("You have not selected a record to be deleted, Please make sure you do in order to proceed");
            }
        }
    }
}
