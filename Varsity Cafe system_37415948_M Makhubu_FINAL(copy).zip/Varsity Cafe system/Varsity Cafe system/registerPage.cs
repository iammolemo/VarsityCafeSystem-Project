﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Varsity_cafe_system
{
    
    public partial class registerPage : Form
    {
        SqlConnection con;
        SqlCommand cmd;
      
        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
        
        public registerPage()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage admin = new adminPage();
            admin.ShowDialog();
        }

        public static bool validatePassword(string pass, string confirmPass)
        {

            if (pass != "" && confirmPass != "")
            {
                if (pass.ToString().Trim().ToLower() == confirmPass.ToString().Trim().ToLower())
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("The Entererd Passwords do not match, Please Check and ensure that they do in order to proceed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);  //showing the error message if password and confirm password doesn't match  
                }

            }
            else
            {
                MessageBox.Show("Please fill all the details required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);  //showing the error message if any fields is empty  
            }
            return false;

        }
        private void clearAll()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtUserName.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginPage login = new LoginPage();
            login.ShowDialog();
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(conString);


            try
            {
                
                bool confirmPassword = validatePassword(txtPassword.Text.ToString(), txtConfirmPassword.Text.ToString());
                if (confirmPassword == true && (txtFirstName.Text != "" || txtLastName.Text != "" || txtUserName.Text != "" || txtEmail.Text != " "))
                {
                     if (con.State != ConnectionState.Open)
                        con.Open();
                    
                      string sql = @"INSERT INTO [EMPLOYEE](Empl_FName,Empl_LName,Empl_Email_Address,Empl_CellNum,Empl_Username,Empl_Password) VALUES(@firstName,@lastName,@email,@cellNo,@username, @password)";
         
                      string pass =txtConfirmPassword.Text;
                      cmd = new SqlCommand(sql, con);

                      cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text);
                      cmd.Parameters.AddWithValue("@lastName", txtLastName.Text);
                      cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                      cmd.Parameters.AddWithValue("@cellNo", txtCellNo.Text);
                      cmd.Parameters.AddWithValue("@userName", txtUserName.Text);
                      cmd.Parameters.AddWithValue("@password", pass);

                      cmd.ExecuteNonQuery();
                      MessageBox.Show("Your account has been successfully registered.", "New user inserted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                      clearAll();
                  
 
                        con.Close();
                }
                else
                {
                    if(confirmPassword == true)
                        MessageBox.Show("Please fill all the the spaces, all details are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                 
            }
            catch 
            {
                MessageBox.Show("This username is already taken", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserName.Clear();
                txtUserName.Focus();
            }
        }
    }
}
