﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class maintainRequestPage : Form
    {
        public maintainRequestPage()
        {
            InitializeComponent();
        }

        private void adminBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage admin = new adminPage();
            admin.ShowDialog();

        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintainMenuPage menu = new maintainMenuPage();
            menu.ShowDialog();
        }

        private void ordersBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrdersPage orders = new OrdersPage();
            orders.ShowDialog();
        }

        private void reportsBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            reportsPage report = new reportsPage();
            report.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            employeesPage empl = new employeesPage();
            empl.ShowDialog();
        }
    }
}
