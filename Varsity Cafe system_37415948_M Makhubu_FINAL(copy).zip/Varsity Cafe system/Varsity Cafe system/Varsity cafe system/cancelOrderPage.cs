﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class cancelOrderPage : Form
    {
        public cancelOrderPage()
        {
            InitializeComponent();
        }
    }
}
