﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class cancelOrderPage : Form
    {
        public cancelOrderPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your order has been succesfully cancelled.");
            this.Hide();
            homePage home = new homePage();
            home.ShowDialog();
        }

        private void noBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            itemsAddedPage added = new itemsAddedPage();
            added.ShowDialog();
        }
    }
}
