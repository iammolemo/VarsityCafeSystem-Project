﻿
namespace Varsity_cafe_system
{
    partial class employeesPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.homeBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.changeBtn = new System.Windows.Forms.Button();
            this.searchLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.menuLbl = new System.Windows.Forms.Label();
            this.maintainGrp = new System.Windows.Forms.GroupBox();
            this.searchTxtBox = new System.Windows.Forms.TextBox();
            this.emplGrid = new System.Windows.Forms.DataGridView();
            this.maintainGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emplGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Red;
            this.homeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.Location = new System.Drawing.Point(785, 559);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(148, 44);
            this.homeBtn.TabIndex = 21;
            this.homeBtn.Text = "GO TO HOME PAGE";
            this.homeBtn.UseVisualStyleBackColor = false;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Red;
            this.deleteBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.Location = new System.Drawing.Point(59, 306);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(152, 44);
            this.deleteBtn.TabIndex = 13;
            this.deleteBtn.Text = "DELETE AN EMPLOYEE";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // changeBtn
            // 
            this.changeBtn.BackColor = System.Drawing.Color.Red;
            this.changeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeBtn.Location = new System.Drawing.Point(59, 186);
            this.changeBtn.Name = "changeBtn";
            this.changeBtn.Size = new System.Drawing.Size(152, 44);
            this.changeBtn.TabIndex = 12;
            this.changeBtn.Text = "MODIFY EMPLOYEE DETAILS";
            this.changeBtn.UseVisualStyleBackColor = false;
            this.changeBtn.Click += new System.EventHandler(this.changeBtn_Click);
            // 
            // searchLbl
            // 
            this.searchLbl.AutoSize = true;
            this.searchLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLbl.Location = new System.Drawing.Point(56, 91);
            this.searchLbl.Name = "searchLbl";
            this.searchLbl.Size = new System.Drawing.Size(52, 16);
            this.searchLbl.TabIndex = 0;
            this.searchLbl.Text = "Search:";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 559);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(180, 44);
            this.backBtn.TabIndex = 20;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // menuLbl
            // 
            this.menuLbl.AutoSize = true;
            this.menuLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuLbl.Location = new System.Drawing.Point(379, 9);
            this.menuLbl.Name = "menuLbl";
            this.menuLbl.Size = new System.Drawing.Size(262, 29);
            this.menuLbl.TabIndex = 19;
            this.menuLbl.Text = "MAINTAIN EMPLOYEES";
            // 
            // maintainGrp
            // 
            this.maintainGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.maintainGrp.Controls.Add(this.searchTxtBox);
            this.maintainGrp.Controls.Add(this.emplGrid);
            this.maintainGrp.Controls.Add(this.deleteBtn);
            this.maintainGrp.Controls.Add(this.changeBtn);
            this.maintainGrp.Controls.Add(this.searchLbl);
            this.maintainGrp.Location = new System.Drawing.Point(20, 66);
            this.maintainGrp.Name = "maintainGrp";
            this.maintainGrp.Size = new System.Drawing.Size(938, 442);
            this.maintainGrp.TabIndex = 18;
            this.maintainGrp.TabStop = false;
            // 
            // searchTxtBox
            // 
            this.searchTxtBox.Location = new System.Drawing.Point(137, 90);
            this.searchTxtBox.Name = "searchTxtBox";
            this.searchTxtBox.Size = new System.Drawing.Size(130, 20);
            this.searchTxtBox.TabIndex = 16;
            this.searchTxtBox.TextChanged += new System.EventHandler(this.searchTxtBox_TextChanged);
            // 
            // emplGrid
            // 
            this.emplGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.emplGrid.Location = new System.Drawing.Point(302, 90);
            this.emplGrid.Name = "emplGrid";
            this.emplGrid.Size = new System.Drawing.Size(626, 343);
            this.emplGrid.TabIndex = 15;
            // 
            // employeesPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(977, 615);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.menuLbl);
            this.Controls.Add(this.maintainGrp);
            this.Name = "employeesPage";
            this.Text = "employeesPage";
            this.Load += new System.EventHandler(this.employeesPage_Load);
            this.maintainGrp.ResumeLayout(false);
            this.maintainGrp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.emplGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button homeBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button changeBtn;
        private System.Windows.Forms.Label searchLbl;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label menuLbl;
        private System.Windows.Forms.GroupBox maintainGrp;
        private System.Windows.Forms.DataGridView emplGrid;
        private System.Windows.Forms.TextBox searchTxtBox;
    }
}