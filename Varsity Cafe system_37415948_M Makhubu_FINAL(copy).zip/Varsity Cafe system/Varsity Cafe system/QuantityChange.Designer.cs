﻿
namespace Varsity_cafe_system
{
    partial class QuantityChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newQuantLbl = new System.Windows.Forms.Label();
            this.changeTxtBox = new System.Windows.Forms.TextBox();
            this.loginBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // newQuantLbl
            // 
            this.newQuantLbl.AutoSize = true;
            this.newQuantLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newQuantLbl.Location = new System.Drawing.Point(164, 37);
            this.newQuantLbl.Name = "newQuantLbl";
            this.newQuantLbl.Size = new System.Drawing.Size(0, 16);
            this.newQuantLbl.TabIndex = 22;
            // 
            // changeTxtBox
            // 
            this.changeTxtBox.Location = new System.Drawing.Point(167, 71);
            this.changeTxtBox.Name = "changeTxtBox";
            this.changeTxtBox.Size = new System.Drawing.Size(134, 20);
            this.changeTxtBox.TabIndex = 21;
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.Color.Red;
            this.loginBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginBtn.Location = new System.Drawing.Point(157, -86);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(158, 36);
            this.loginBtn.TabIndex = 23;
            this.loginBtn.Text = "LOGIN";
            this.loginBtn.UseVisualStyleBackColor = false;
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.Red;
            this.updateBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.Location = new System.Drawing.Point(167, 119);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(158, 36);
            this.updateBtn.TabIndex = 24;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // QuantityChange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 185);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.newQuantLbl);
            this.Controls.Add(this.changeTxtBox);
            this.Controls.Add(this.loginBtn);
            this.Name = "QuantityChange";
            this.Text = "QuantityChange";
            this.Load += new System.EventHandler(this.QuantityChange_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label newQuantLbl;
        private System.Windows.Forms.TextBox changeTxtBox;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.Button updateBtn;
    }
}