﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Varsity_cafe_system
{
    public partial class QuantityChange : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        


        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
       
        public QuantityChange()

        {
            InitializeComponent();
        }

        private void QuantityChange_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(conString);
            con.Open();
            newQuantLbl.Text = "PLease enter the new quantity for the selcted order ";
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            
        }
    }
}
