﻿
namespace Varsity_cafe_system
{
    partial class reportsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportsComb = new System.Windows.Forms.ComboBox();
            this.homeBtn = new System.Windows.Forms.Button();
            this.maintainGrp = new System.Windows.Forms.GroupBox();
            this.reportsGrid = new System.Windows.Forms.DataGridView();
            this.searchLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.reportsLbl = new System.Windows.Forms.Label();
            this.viewLbl = new System.Windows.Forms.Label();
            this.searchTxtBox = new System.Windows.Forms.TextBox();
            this.maintainGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportsGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // reportsComb
            // 
            this.reportsComb.FormattingEnabled = true;
            this.reportsComb.Items.AddRange(new object[] {
            "Employees Reports",
            "Orders Reports"});
            this.reportsComb.Location = new System.Drawing.Point(44, 61);
            this.reportsComb.Name = "reportsComb";
            this.reportsComb.Size = new System.Drawing.Size(121, 21);
            this.reportsComb.TabIndex = 0;
            this.reportsComb.SelectedIndexChanged += new System.EventHandler(this.reportsComb_SelectedIndexChanged);
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Red;
            this.homeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.Location = new System.Drawing.Point(782, 521);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(148, 44);
            this.homeBtn.TabIndex = 25;
            this.homeBtn.Text = "GO TO HOME PAGE";
            this.homeBtn.UseVisualStyleBackColor = false;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // maintainGrp
            // 
            this.maintainGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.maintainGrp.Controls.Add(this.searchTxtBox);
            this.maintainGrp.Controls.Add(this.viewLbl);
            this.maintainGrp.Controls.Add(this.reportsGrid);
            this.maintainGrp.Controls.Add(this.searchLbl);
            this.maintainGrp.Controls.Add(this.reportsComb);
            this.maintainGrp.Location = new System.Drawing.Point(13, 48);
            this.maintainGrp.Name = "maintainGrp";
            this.maintainGrp.Size = new System.Drawing.Size(938, 442);
            this.maintainGrp.TabIndex = 22;
            this.maintainGrp.TabStop = false;
            this.maintainGrp.Enter += new System.EventHandler(this.maintainGrp_Enter);
            // 
            // reportsGrid
            // 
            this.reportsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportsGrid.Location = new System.Drawing.Point(6, 172);
            this.reportsGrid.Name = "reportsGrid";
            this.reportsGrid.Size = new System.Drawing.Size(922, 261);
            this.reportsGrid.TabIndex = 15;
            // 
            // searchLbl
            // 
            this.searchLbl.AutoSize = true;
            this.searchLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLbl.Location = new System.Drawing.Point(41, 111);
            this.searchLbl.Name = "searchLbl";
            this.searchLbl.Size = new System.Drawing.Size(52, 16);
            this.searchLbl.TabIndex = 0;
            this.searchLbl.Text = "Search:";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(13, 521);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(180, 44);
            this.backBtn.TabIndex = 24;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // reportsLbl
            // 
            this.reportsLbl.AutoSize = true;
            this.reportsLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportsLbl.Location = new System.Drawing.Point(442, 16);
            this.reportsLbl.Name = "reportsLbl";
            this.reportsLbl.Size = new System.Drawing.Size(116, 29);
            this.reportsLbl.TabIndex = 23;
            this.reportsLbl.Text = "REPORTS";
            // 
            // viewLbl
            // 
            this.viewLbl.AutoSize = true;
            this.viewLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewLbl.Location = new System.Drawing.Point(32, 30);
            this.viewLbl.Name = "viewLbl";
            this.viewLbl.Size = new System.Drawing.Size(278, 16);
            this.viewLbl.TabIndex = 16;
            this.viewLbl.Text = "Please select a record you\'d like to view below:";
            // 
            // searchTxtBox
            // 
            this.searchTxtBox.Location = new System.Drawing.Point(112, 110);
            this.searchTxtBox.Name = "searchTxtBox";
            this.searchTxtBox.Size = new System.Drawing.Size(121, 20);
            this.searchTxtBox.TabIndex = 17;
            this.searchTxtBox.TextChanged += new System.EventHandler(this.searchTxtBox_TextChanged);
            // 
            // reportsPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(975, 577);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.maintainGrp);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.reportsLbl);
            this.Name = "reportsPage";
            this.Text = "reportsPage";
            this.maintainGrp.ResumeLayout(false);
            this.maintainGrp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reportsGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox reportsComb;
        private System.Windows.Forms.Button homeBtn;
        private System.Windows.Forms.GroupBox maintainGrp;
        private System.Windows.Forms.DataGridView reportsGrid;
        private System.Windows.Forms.Label searchLbl;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label reportsLbl;
        private System.Windows.Forms.Label viewLbl;
        private System.Windows.Forms.TextBox searchTxtBox;
    }
}