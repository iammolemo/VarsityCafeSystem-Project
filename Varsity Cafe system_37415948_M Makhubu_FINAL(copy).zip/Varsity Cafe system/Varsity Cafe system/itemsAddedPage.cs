﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class itemsAddedPage : Form
    {
        public itemsAddedPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainMenu main = new mainMenu();
            main.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            cancelOrderPage cancel = new cancelOrderPage();
            cancel.ShowDialog();
        }

        private void checkoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            paymentPage pay = new paymentPage();
            pay.ShowDialog();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            quantityPage quant = new quantityPage();
            quant.ShowDialog();
        }
    }
}
