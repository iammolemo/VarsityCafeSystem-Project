﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class quantityPage : Form
    {
        public quantityPage()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainMenu main = new mainMenu();
            main.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radOne.Checked)
            {
                this.Hide();
                itemsAddedPage added = new itemsAddedPage();
                added.ShowDialog();
            }
            else if (radTwo.Checked)
            {
                this.Hide();
                itemsAddedPage added = new itemsAddedPage();
                added.ShowDialog();
            }
            else if (radThree.Checked)
            {
                this.Hide();
                itemsAddedPage added = new itemsAddedPage();
                added.ShowDialog();
            }
            else if (ownQuantRad.Checked)
            {
                if (ownQuantRad.Checked && quantTxtBox.Text != "")
                {
                    this.Hide();
                    itemsAddedPage added = new itemsAddedPage();
                    added.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Please indicate the quantity of your item next to you selected option to proceed with your order.");
                }
            }
            else
            {
                MessageBox.Show("Please make sure you have s from one of the option in order to proceed with your order.");
            }
        }
    }
}
