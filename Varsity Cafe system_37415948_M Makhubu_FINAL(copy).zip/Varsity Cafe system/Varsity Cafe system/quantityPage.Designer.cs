﻿
namespace Varsity_cafe_system
{
    partial class quantityPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radOne = new System.Windows.Forms.RadioButton();
            this.radTwo = new System.Windows.Forms.RadioButton();
            this.radThree = new System.Windows.Forms.RadioButton();
            this.nextBtn = new System.Windows.Forms.Button();
            this.quantTxtBox = new System.Windows.Forms.TextBox();
            this.backToMenuBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ownQuantRad = new System.Windows.Forms.RadioButton();
            this.quantityGrp = new System.Windows.Forms.GroupBox();
            this.quantityGrp.SuspendLayout();
            this.SuspendLayout();
            // 
            // radOne
            // 
            this.radOne.AutoSize = true;
            this.radOne.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radOne.Location = new System.Drawing.Point(6, 19);
            this.radOne.Name = "radOne";
            this.radOne.Size = new System.Drawing.Size(30, 20);
            this.radOne.TabIndex = 0;
            this.radOne.TabStop = true;
            this.radOne.Text = "1";
            this.radOne.UseVisualStyleBackColor = true;
            // 
            // radTwo
            // 
            this.radTwo.AutoSize = true;
            this.radTwo.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTwo.Location = new System.Drawing.Point(6, 52);
            this.radTwo.Name = "radTwo";
            this.radTwo.Size = new System.Drawing.Size(33, 20);
            this.radTwo.TabIndex = 1;
            this.radTwo.TabStop = true;
            this.radTwo.Text = "2";
            this.radTwo.UseVisualStyleBackColor = true;
            // 
            // radThree
            // 
            this.radThree.AutoSize = true;
            this.radThree.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radThree.Location = new System.Drawing.Point(6, 87);
            this.radThree.Name = "radThree";
            this.radThree.Size = new System.Drawing.Size(33, 20);
            this.radThree.TabIndex = 2;
            this.radThree.TabStop = true;
            this.radThree.Text = "3";
            this.radThree.UseVisualStyleBackColor = true;
            // 
            // nextBtn
            // 
            this.nextBtn.BackColor = System.Drawing.Color.Red;
            this.nextBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextBtn.Location = new System.Drawing.Point(404, 228);
            this.nextBtn.Name = "nextBtn";
            this.nextBtn.Size = new System.Drawing.Size(94, 37);
            this.nextBtn.TabIndex = 3;
            this.nextBtn.Text = "NEXT";
            this.nextBtn.UseVisualStyleBackColor = false;
            this.nextBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // quantTxtBox
            // 
            this.quantTxtBox.Location = new System.Drawing.Point(172, 117);
            this.quantTxtBox.Name = "quantTxtBox";
            this.quantTxtBox.Size = new System.Drawing.Size(100, 20);
            this.quantTxtBox.TabIndex = 4;
            // 
            // backToMenuBtn
            // 
            this.backToMenuBtn.BackColor = System.Drawing.Color.Red;
            this.backToMenuBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backToMenuBtn.Location = new System.Drawing.Point(8, 228);
            this.backToMenuBtn.Name = "backToMenuBtn";
            this.backToMenuBtn.Size = new System.Drawing.Size(194, 37);
            this.backToMenuBtn.TabIndex = 5;
            this.backToMenuBtn.Text = "RETURN TO MAIN MENU";
            this.backToMenuBtn.UseVisualStyleBackColor = false;
            this.backToMenuBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(130, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "How many of this item would you like to order";
            // 
            // ownQuantRad
            // 
            this.ownQuantRad.AutoSize = true;
            this.ownQuantRad.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ownQuantRad.Location = new System.Drawing.Point(6, 120);
            this.ownQuantRad.Name = "ownQuantRad";
            this.ownQuantRad.Size = new System.Drawing.Size(153, 20);
            this.ownQuantRad.TabIndex = 7;
            this.ownQuantRad.TabStop = true;
            this.ownQuantRad.Text = "Enter my own quantity";
            this.ownQuantRad.UseVisualStyleBackColor = true;
            // 
            // quantityGrp
            // 
            this.quantityGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.quantityGrp.Controls.Add(this.radOne);
            this.quantityGrp.Controls.Add(this.ownQuantRad);
            this.quantityGrp.Controls.Add(this.radTwo);
            this.quantityGrp.Controls.Add(this.quantTxtBox);
            this.quantityGrp.Controls.Add(this.radThree);
            this.quantityGrp.Location = new System.Drawing.Point(23, 35);
            this.quantityGrp.Name = "quantityGrp";
            this.quantityGrp.Size = new System.Drawing.Size(295, 155);
            this.quantityGrp.TabIndex = 8;
            this.quantityGrp.TabStop = false;
            // 
            // quantityPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(510, 277);
            this.Controls.Add(this.quantityGrp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.backToMenuBtn);
            this.Controls.Add(this.nextBtn);
            this.Name = "quantityPage";
            this.Text = "quantityPage";
            this.quantityGrp.ResumeLayout(false);
            this.quantityGrp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radOne;
        private System.Windows.Forms.RadioButton radTwo;
        private System.Windows.Forms.RadioButton radThree;
        private System.Windows.Forms.Button nextBtn;
        private System.Windows.Forms.TextBox quantTxtBox;
        private System.Windows.Forms.Button backToMenuBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton ownQuantRad;
        private System.Windows.Forms.GroupBox quantityGrp;
    }
}