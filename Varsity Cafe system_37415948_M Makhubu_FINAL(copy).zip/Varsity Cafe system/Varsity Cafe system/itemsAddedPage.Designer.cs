﻿
namespace Varsity_cafe_system
{
    partial class itemsAddedPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(itemsAddedPage));
            this.menuBtn = new System.Windows.Forms.Button();
            this.checkoutBtn = new System.Windows.Forms.Button();
            this.cancelHomeBtn = new System.Windows.Forms.Button();
            this.backToQuantBtn = new System.Windows.Forms.Button();
            this.itemsAddedGrpBox = new System.Windows.Forms.GroupBox();
            this.logoPicBx = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.itemsAddedGrpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).BeginInit();
            this.SuspendLayout();
            // 
            // menuBtn
            // 
            this.menuBtn.BackColor = System.Drawing.Color.Red;
            this.menuBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuBtn.Location = new System.Drawing.Point(65, 38);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(219, 42);
            this.menuBtn.TabIndex = 1;
            this.menuBtn.Text = "RETURN TO MAIN MENU";
            this.menuBtn.UseVisualStyleBackColor = false;
            this.menuBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkoutBtn
            // 
            this.checkoutBtn.BackColor = System.Drawing.Color.Red;
            this.checkoutBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkoutBtn.Location = new System.Drawing.Point(65, 104);
            this.checkoutBtn.Name = "checkoutBtn";
            this.checkoutBtn.Size = new System.Drawing.Size(217, 43);
            this.checkoutBtn.TabIndex = 2;
            this.checkoutBtn.Text = "PROCEED TO CHECKOUT";
            this.checkoutBtn.UseVisualStyleBackColor = false;
            this.checkoutBtn.Click += new System.EventHandler(this.checkoutBtn_Click);
            // 
            // cancelHomeBtn
            // 
            this.cancelHomeBtn.BackColor = System.Drawing.Color.Red;
            this.cancelHomeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelHomeBtn.Location = new System.Drawing.Point(65, 169);
            this.cancelHomeBtn.Name = "cancelHomeBtn";
            this.cancelHomeBtn.Size = new System.Drawing.Size(217, 48);
            this.cancelHomeBtn.TabIndex = 3;
            this.cancelHomeBtn.Text = "CANCEL ORDER AND RETURN TO HOME PAGE";
            this.cancelHomeBtn.UseVisualStyleBackColor = false;
            this.cancelHomeBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // backToQuantBtn
            // 
            this.backToQuantBtn.BackColor = System.Drawing.Color.Red;
            this.backToQuantBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backToQuantBtn.Location = new System.Drawing.Point(12, 343);
            this.backToQuantBtn.Name = "backToQuantBtn";
            this.backToQuantBtn.Size = new System.Drawing.Size(205, 36);
            this.backToQuantBtn.TabIndex = 4;
            this.backToQuantBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backToQuantBtn.UseVisualStyleBackColor = false;
            this.backToQuantBtn.Click += new System.EventHandler(this.button4_Click);
            // 
            // itemsAddedGrpBox
            // 
            this.itemsAddedGrpBox.BackColor = System.Drawing.Color.Gainsboro;
            this.itemsAddedGrpBox.Controls.Add(this.menuBtn);
            this.itemsAddedGrpBox.Controls.Add(this.checkoutBtn);
            this.itemsAddedGrpBox.Controls.Add(this.cancelHomeBtn);
            this.itemsAddedGrpBox.Location = new System.Drawing.Point(148, 65);
            this.itemsAddedGrpBox.Name = "itemsAddedGrpBox";
            this.itemsAddedGrpBox.Size = new System.Drawing.Size(357, 243);
            this.itemsAddedGrpBox.TabIndex = 5;
            this.itemsAddedGrpBox.TabStop = false;
            // 
            // logoPicBx
            // 
            this.logoPicBx.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBx.Image")));
            this.logoPicBx.Location = new System.Drawing.Point(614, 12);
            this.logoPicBx.Name = "logoPicBx";
            this.logoPicBx.Size = new System.Drawing.Size(70, 44);
            this.logoPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBx.TabIndex = 9;
            this.logoPicBx.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(145, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(383, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "YOUR ITEMS HAVE BEEN SUCCESSFULLY ADDED TO YOUR CART!";
            // 
            // itemsAddedPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(696, 391);
            this.Controls.Add(this.logoPicBx);
            this.Controls.Add(this.itemsAddedGrpBox);
            this.Controls.Add(this.backToQuantBtn);
            this.Controls.Add(this.label1);
            this.Name = "itemsAddedPage";
            this.Text = "itemsAddedPage";
            this.itemsAddedGrpBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button menuBtn;
        private System.Windows.Forms.Button checkoutBtn;
        private System.Windows.Forms.Button cancelHomeBtn;
        private System.Windows.Forms.Button backToQuantBtn;
        private System.Windows.Forms.GroupBox itemsAddedGrpBox;
        private System.Windows.Forms.PictureBox logoPicBx;
        private System.Windows.Forms.Label label1;
    }
}