﻿
namespace Varsity_cafe_system
{
    partial class maintainRequestPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(maintainRequestPage));
            this.adminBtn = new System.Windows.Forms.Button();
            this.deleteGrp = new System.Windows.Forms.GroupBox();
            this.employeesBtn = new System.Windows.Forms.Button();
            this.menuBtn = new System.Windows.Forms.Button();
            this.ordersBtn = new System.Windows.Forms.Button();
            this.reportsBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.headerLbl = new System.Windows.Forms.Label();
            this.deleteGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // adminBtn
            // 
            this.adminBtn.BackColor = System.Drawing.Color.Red;
            this.adminBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminBtn.Location = new System.Drawing.Point(12, 345);
            this.adminBtn.Name = "adminBtn";
            this.adminBtn.Size = new System.Drawing.Size(183, 44);
            this.adminBtn.TabIndex = 11;
            this.adminBtn.Text = "RETURN TO ADMIN PAGE";
            this.adminBtn.UseVisualStyleBackColor = false;
            this.adminBtn.Click += new System.EventHandler(this.adminBtn_Click);
            // 
            // deleteGrp
            // 
            this.deleteGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.deleteGrp.Controls.Add(this.employeesBtn);
            this.deleteGrp.Controls.Add(this.menuBtn);
            this.deleteGrp.Controls.Add(this.ordersBtn);
            this.deleteGrp.Controls.Add(this.reportsBtn);
            this.deleteGrp.Location = new System.Drawing.Point(120, 87);
            this.deleteGrp.Name = "deleteGrp";
            this.deleteGrp.Size = new System.Drawing.Size(425, 252);
            this.deleteGrp.TabIndex = 10;
            this.deleteGrp.TabStop = false;
            // 
            // employeesBtn
            // 
            this.employeesBtn.BackColor = System.Drawing.Color.Red;
            this.employeesBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeesBtn.Location = new System.Drawing.Point(107, 138);
            this.employeesBtn.Name = "employeesBtn";
            this.employeesBtn.Size = new System.Drawing.Size(222, 44);
            this.employeesBtn.TabIndex = 5;
            this.employeesBtn.Text = "MAINTAIN EMPLOYEES";
            this.employeesBtn.UseVisualStyleBackColor = false;
            this.employeesBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuBtn
            // 
            this.menuBtn.BackColor = System.Drawing.Color.Red;
            this.menuBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuBtn.Location = new System.Drawing.Point(107, 35);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(222, 47);
            this.menuBtn.TabIndex = 4;
            this.menuBtn.Text = "MAINTAIN MENU";
            this.menuBtn.UseVisualStyleBackColor = false;
            this.menuBtn.Click += new System.EventHandler(this.menuBtn_Click);
            // 
            // ordersBtn
            // 
            this.ordersBtn.BackColor = System.Drawing.Color.Red;
            this.ordersBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ordersBtn.Location = new System.Drawing.Point(107, 88);
            this.ordersBtn.Name = "ordersBtn";
            this.ordersBtn.Size = new System.Drawing.Size(222, 44);
            this.ordersBtn.TabIndex = 3;
            this.ordersBtn.Text = "MAINTAIN ORDERS";
            this.ordersBtn.UseVisualStyleBackColor = false;
            this.ordersBtn.Click += new System.EventHandler(this.ordersBtn_Click);
            // 
            // reportsBtn
            // 
            this.reportsBtn.BackColor = System.Drawing.Color.Red;
            this.reportsBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportsBtn.Location = new System.Drawing.Point(107, 188);
            this.reportsBtn.Name = "reportsBtn";
            this.reportsBtn.Size = new System.Drawing.Size(222, 41);
            this.reportsBtn.TabIndex = 2;
            this.reportsBtn.Text = "REPORTS";
            this.reportsBtn.UseVisualStyleBackColor = false;
            this.reportsBtn.Click += new System.EventHandler(this.reportsBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(645, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // headerLbl
            // 
            this.headerLbl.AutoSize = true;
            this.headerLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headerLbl.Location = new System.Drawing.Point(296, 9);
            this.headerLbl.Name = "headerLbl";
            this.headerLbl.Size = new System.Drawing.Size(88, 29);
            this.headerLbl.TabIndex = 12;
            this.headerLbl.Text = "LOGIN ";
            // 
            // maintainRequestPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(725, 401);
            this.Controls.Add(this.adminBtn);
            this.Controls.Add(this.deleteGrp);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.headerLbl);
            this.Name = "maintainRequestPage";
            this.Text = "maintainRequestPage";
            this.deleteGrp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button adminBtn;
        private System.Windows.Forms.GroupBox deleteGrp;
        private System.Windows.Forms.Button reportsBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label headerLbl;
        private System.Windows.Forms.Button menuBtn;
        private System.Windows.Forms.Button ordersBtn;
        private System.Windows.Forms.Button employeesBtn;
    }
}