﻿
namespace Varsity_cafe_system
{
    partial class toastiesMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(toastiesMenu));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.biltongBtn = new System.Windows.Forms.Button();
            this.minceBtn = new System.Windows.Forms.Button();
            this.hamBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.minceLbl = new System.Windows.Forms.Label();
            this.hamLbl = new System.Windows.Forms.Label();
            this.menuHearderLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.logoPicBx = new System.Windows.Forms.PictureBox();
            this.chickenMayoBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.eggBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.dagwoodBtn = new System.Windows.Forms.Button();
            this.dagwoodLbl = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.dagwoodBtn);
            this.groupBox1.Controls.Add(this.dagwoodLbl);
            this.groupBox1.Controls.Add(this.eggBtn);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.chickenMayoBtn);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.biltongBtn);
            this.groupBox1.Controls.Add(this.minceBtn);
            this.groupBox1.Controls.Add(this.hamBtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.minceLbl);
            this.groupBox1.Controls.Add(this.hamLbl);
            this.groupBox1.Location = new System.Drawing.Point(127, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(526, 407);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // biltongBtn
            // 
            this.biltongBtn.BackColor = System.Drawing.Color.Red;
            this.biltongBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.biltongBtn.Location = new System.Drawing.Point(349, 172);
            this.biltongBtn.Name = "biltongBtn";
            this.biltongBtn.Size = new System.Drawing.Size(121, 38);
            this.biltongBtn.TabIndex = 5;
            this.biltongBtn.Text = "R30";
            this.biltongBtn.UseVisualStyleBackColor = false;
            this.biltongBtn.Click += new System.EventHandler(this.biltongBtn_Click);
            // 
            // minceBtn
            // 
            this.minceBtn.BackColor = System.Drawing.Color.Red;
            this.minceBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minceBtn.Location = new System.Drawing.Point(349, 122);
            this.minceBtn.Name = "minceBtn";
            this.minceBtn.Size = new System.Drawing.Size(121, 35);
            this.minceBtn.TabIndex = 4;
            this.minceBtn.Text = "R30";
            this.minceBtn.UseVisualStyleBackColor = false;
            this.minceBtn.Click += new System.EventHandler(this.minceBtn_Click);
            // 
            // hamBtn
            // 
            this.hamBtn.BackColor = System.Drawing.Color.Red;
            this.hamBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hamBtn.Location = new System.Drawing.Point(349, 62);
            this.hamBtn.Name = "hamBtn";
            this.hamBtn.Size = new System.Drawing.Size(121, 35);
            this.hamBtn.TabIndex = 3;
            this.hamBtn.Text = "R26";
            this.hamBtn.UseVisualStyleBackColor = false;
            this.hamBtn.Click += new System.EventHandler(this.hamBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(73, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "BILTONG AND CHEESE";
            // 
            // minceLbl
            // 
            this.minceLbl.AutoSize = true;
            this.minceLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minceLbl.Location = new System.Drawing.Point(73, 131);
            this.minceLbl.Name = "minceLbl";
            this.minceLbl.Size = new System.Drawing.Size(128, 16);
            this.minceLbl.TabIndex = 1;
            this.minceLbl.Text = "MINCE AND CHEESE";
            // 
            // hamLbl
            // 
            this.hamLbl.AutoSize = true;
            this.hamLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hamLbl.Location = new System.Drawing.Point(73, 71);
            this.hamLbl.Name = "hamLbl";
            this.hamLbl.Size = new System.Drawing.Size(116, 16);
            this.hamLbl.TabIndex = 0;
            this.hamLbl.Text = "HAM AND CHEESE";
            // 
            // menuHearderLbl
            // 
            this.menuHearderLbl.AutoSize = true;
            this.menuHearderLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuHearderLbl.Location = new System.Drawing.Point(278, 22);
            this.menuHearderLbl.Name = "menuHearderLbl";
            this.menuHearderLbl.Size = new System.Drawing.Size(189, 29);
            this.menuHearderLbl.TabIndex = 7;
            this.menuHearderLbl.Text = "TOASTIES MENU";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 492);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(195, 39);
            this.backBtn.TabIndex = 6;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // logoPicBx
            // 
            this.logoPicBx.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBx.Image")));
            this.logoPicBx.Location = new System.Drawing.Point(765, -10);
            this.logoPicBx.Name = "logoPicBx";
            this.logoPicBx.Size = new System.Drawing.Size(70, 44);
            this.logoPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBx.TabIndex = 4;
            this.logoPicBx.TabStop = false;
            // 
            // chickenMayoBtn
            // 
            this.chickenMayoBtn.BackColor = System.Drawing.Color.Red;
            this.chickenMayoBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenMayoBtn.Location = new System.Drawing.Point(349, 220);
            this.chickenMayoBtn.Name = "chickenMayoBtn";
            this.chickenMayoBtn.Size = new System.Drawing.Size(121, 38);
            this.chickenMayoBtn.TabIndex = 7;
            this.chickenMayoBtn.Text = "R28";
            this.chickenMayoBtn.UseVisualStyleBackColor = false;
            this.chickenMayoBtn.Click += new System.EventHandler(this.chickenMayoBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(73, 231);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "CHICKEN MAYO";
            // 
            // eggBtn
            // 
            this.eggBtn.BackColor = System.Drawing.Color.Red;
            this.eggBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eggBtn.Location = new System.Drawing.Point(349, 285);
            this.eggBtn.Name = "eggBtn";
            this.eggBtn.Size = new System.Drawing.Size(121, 38);
            this.eggBtn.TabIndex = 9;
            this.eggBtn.Text = "R32";
            this.eggBtn.UseVisualStyleBackColor = false;
            this.eggBtn.Click += new System.EventHandler(this.eggBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(73, 296);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "BACON, EGG AND CHEESE";
            // 
            // dagwoodBtn
            // 
            this.dagwoodBtn.BackColor = System.Drawing.Color.Red;
            this.dagwoodBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dagwoodBtn.Location = new System.Drawing.Point(349, 343);
            this.dagwoodBtn.Name = "dagwoodBtn";
            this.dagwoodBtn.Size = new System.Drawing.Size(121, 38);
            this.dagwoodBtn.TabIndex = 11;
            this.dagwoodBtn.Text = "R65";
            this.dagwoodBtn.UseVisualStyleBackColor = false;
            // 
            // dagwoodLbl
            // 
            this.dagwoodLbl.AutoSize = true;
            this.dagwoodLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dagwoodLbl.Location = new System.Drawing.Point(73, 354);
            this.dagwoodLbl.Name = "dagwoodLbl";
            this.dagwoodLbl.Size = new System.Drawing.Size(129, 16);
            this.dagwoodLbl.TabIndex = 10;
            this.dagwoodLbl.Text = "DAGWOOD AND CHIP";
            // 
            // toastiesMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 554);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuHearderLbl);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.logoPicBx);
            this.Name = "toastiesMenu";
            this.Text = "toastiesMenu";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button biltongBtn;
        private System.Windows.Forms.Button minceBtn;
        private System.Windows.Forms.Button hamBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label minceLbl;
        private System.Windows.Forms.Label hamLbl;
        private System.Windows.Forms.Label menuHearderLbl;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.PictureBox logoPicBx;
        private System.Windows.Forms.Button dagwoodBtn;
        private System.Windows.Forms.Label dagwoodLbl;
        private System.Windows.Forms.Button eggBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button chickenMayoBtn;
        private System.Windows.Forms.Label label1;
    }
}