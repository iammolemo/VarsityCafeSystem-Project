﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class beveragesMenu : Form
    {
        public void ShowQuantityPage()// Function that hide a current page and shows the quantity page
        {
            this.Hide();
            quantityPage quantity = new quantityPage();
            quantity.ShowDialog();
        }
        public void ShowMainMenu()// Function that hide a current page and shows the main menu page
        {
            this.Hide();
            mainMenu main = new mainMenu();
            main.ShowDialog();
        }

        public beveragesMenu()
        {
            InitializeComponent();
        }

        private void sweetChilliBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            ShowMainMenu();
        }

        private void fantsOBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void spriteBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void lemonBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void appleJBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void strawberryMilkBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void blueMilkBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void coffBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void cuppacBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }

        private void hotChocBtn_Click(object sender, EventArgs e)
        {
            ShowQuantityPage();
        }
    }
}
