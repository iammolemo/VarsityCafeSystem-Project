﻿
namespace Varsity_cafe_system
{
    partial class maintainMenuPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.maintainGrp = new System.Windows.Forms.GroupBox();
            this.searchTxtBox = new System.Windows.Forms.TextBox();
            this.addGrpBx = new System.Windows.Forms.GroupBox();
            this.add = new System.Windows.Forms.Button();
            this.priceTxt = new System.Windows.Forms.MaskedTextBox();
            this.foodPrice = new System.Windows.Forms.Label();
            this.quantTxtBox = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.foodTxt = new System.Windows.Forms.MaskedTextBox();
            this.foodName = new System.Windows.Forms.Label();
            this.menuItemGrid = new System.Windows.Forms.DataGridView();
            this.addBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.changeBtn = new System.Windows.Forms.Button();
            this.searchLbl = new System.Windows.Forms.Label();
            this.menuLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.homeBtn = new System.Windows.Forms.Button();
            this.maintainGrp.SuspendLayout();
            this.addGrpBx.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuItemGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // maintainGrp
            // 
            this.maintainGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.maintainGrp.Controls.Add(this.searchTxtBox);
            this.maintainGrp.Controls.Add(this.addGrpBx);
            this.maintainGrp.Controls.Add(this.menuItemGrid);
            this.maintainGrp.Controls.Add(this.addBtn);
            this.maintainGrp.Controls.Add(this.deleteBtn);
            this.maintainGrp.Controls.Add(this.changeBtn);
            this.maintainGrp.Controls.Add(this.searchLbl);
            this.maintainGrp.Location = new System.Drawing.Point(27, 54);
            this.maintainGrp.Name = "maintainGrp";
            this.maintainGrp.Size = new System.Drawing.Size(938, 481);
            this.maintainGrp.TabIndex = 0;
            this.maintainGrp.TabStop = false;
            // 
            // searchTxtBox
            // 
            this.searchTxtBox.Location = new System.Drawing.Point(687, 25);
            this.searchTxtBox.Name = "searchTxtBox";
            this.searchTxtBox.Size = new System.Drawing.Size(130, 20);
            this.searchTxtBox.TabIndex = 17;
            this.searchTxtBox.TextChanged += new System.EventHandler(this.searchTxtBox_TextChanged);
            // 
            // addGrpBx
            // 
            this.addGrpBx.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.addGrpBx.Controls.Add(this.add);
            this.addGrpBx.Controls.Add(this.priceTxt);
            this.addGrpBx.Controls.Add(this.foodPrice);
            this.addGrpBx.Controls.Add(this.quantTxtBox);
            this.addGrpBx.Controls.Add(this.label3);
            this.addGrpBx.Controls.Add(this.foodTxt);
            this.addGrpBx.Controls.Add(this.foodName);
            this.addGrpBx.Location = new System.Drawing.Point(6, 95);
            this.addGrpBx.Name = "addGrpBx";
            this.addGrpBx.Size = new System.Drawing.Size(279, 221);
            this.addGrpBx.TabIndex = 16;
            this.addGrpBx.TabStop = false;
            this.addGrpBx.Visible = false;
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.Red;
            this.add.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add.Location = new System.Drawing.Point(75, 177);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(94, 44);
            this.add.TabIndex = 17;
            this.add.Text = "ADD";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // priceTxt
            // 
            this.priceTxt.Location = new System.Drawing.Point(132, 132);
            this.priceTxt.Name = "priceTxt";
            this.priceTxt.Size = new System.Drawing.Size(117, 20);
            this.priceTxt.TabIndex = 7;
            this.priceTxt.Visible = false;
            // 
            // foodPrice
            // 
            this.foodPrice.AutoSize = true;
            this.foodPrice.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodPrice.Location = new System.Drawing.Point(6, 136);
            this.foodPrice.Name = "foodPrice";
            this.foodPrice.Size = new System.Drawing.Size(120, 16);
            this.foodPrice.TabIndex = 6;
            this.foodPrice.Text = "Price per food item:";
            this.foodPrice.Visible = false;
            // 
            // quantTxtBox
            // 
            this.quantTxtBox.Location = new System.Drawing.Point(132, 90);
            this.quantTxtBox.Name = "quantTxtBox";
            this.quantTxtBox.Size = new System.Drawing.Size(117, 20);
            this.quantTxtBox.TabIndex = 5;
            this.quantTxtBox.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Quantity:";
            this.label3.Visible = false;
            // 
            // foodTxt
            // 
            this.foodTxt.Location = new System.Drawing.Point(132, 53);
            this.foodTxt.Name = "foodTxt";
            this.foodTxt.Size = new System.Drawing.Size(117, 20);
            this.foodTxt.TabIndex = 3;
            this.foodTxt.Visible = false;
            // 
            // foodName
            // 
            this.foodName.AutoSize = true;
            this.foodName.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodName.Location = new System.Drawing.Point(11, 57);
            this.foodName.Name = "foodName";
            this.foodName.Size = new System.Drawing.Size(76, 16);
            this.foodName.TabIndex = 2;
            this.foodName.Text = "Food Name:";
            this.foodName.Visible = false;
            // 
            // menuItemGrid
            // 
            this.menuItemGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.menuItemGrid.Location = new System.Drawing.Point(313, 67);
            this.menuItemGrid.Name = "menuItemGrid";
            this.menuItemGrid.Size = new System.Drawing.Size(619, 343);
            this.menuItemGrid.TabIndex = 15;
            // 
            // addBtn
            // 
            this.addBtn.BackColor = System.Drawing.Color.Red;
            this.addBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.Location = new System.Drawing.Point(52, 45);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(183, 44);
            this.addBtn.TabIndex = 14;
            this.addBtn.Text = "ADD A MENU ITEM";
            this.addBtn.UseVisualStyleBackColor = false;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Red;
            this.deleteBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.Location = new System.Drawing.Point(669, 431);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(152, 44);
            this.deleteBtn.TabIndex = 13;
            this.deleteBtn.Text = "DELETE A MENU ITEM";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // changeBtn
            // 
            this.changeBtn.BackColor = System.Drawing.Color.Red;
            this.changeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeBtn.Location = new System.Drawing.Point(81, 334);
            this.changeBtn.Name = "changeBtn";
            this.changeBtn.Size = new System.Drawing.Size(130, 44);
            this.changeBtn.TabIndex = 12;
            this.changeBtn.Text = "MODIFY A MENU ITEM";
            this.changeBtn.UseVisualStyleBackColor = false;
            this.changeBtn.Click += new System.EventHandler(this.changeBtn_Click);
            // 
            // searchLbl
            // 
            this.searchLbl.AutoSize = true;
            this.searchLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLbl.Location = new System.Drawing.Point(629, 26);
            this.searchLbl.Name = "searchLbl";
            this.searchLbl.Size = new System.Drawing.Size(52, 16);
            this.searchLbl.TabIndex = 0;
            this.searchLbl.Text = "Search:";
            // 
            // menuLbl
            // 
            this.menuLbl.AutoSize = true;
            this.menuLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuLbl.Location = new System.Drawing.Point(373, 22);
            this.menuLbl.Name = "menuLbl";
            this.menuLbl.Size = new System.Drawing.Size(196, 29);
            this.menuLbl.TabIndex = 10;
            this.menuLbl.Text = "MAINTAIN MENU";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 582);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(164, 44);
            this.backBtn.TabIndex = 12;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Red;
            this.homeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.Location = new System.Drawing.Point(842, 582);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(148, 44);
            this.homeBtn.TabIndex = 13;
            this.homeBtn.Text = "GO TO HOME PAGE";
            this.homeBtn.UseVisualStyleBackColor = false;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // maintainMenuPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1002, 638);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.menuLbl);
            this.Controls.Add(this.maintainGrp);
            this.Name = "maintainMenuPage";
            this.Text = "maintainMenuPage";
            this.Load += new System.EventHandler(this.maintainMenuPage_Load);
            this.maintainGrp.ResumeLayout(false);
            this.maintainGrp.PerformLayout();
            this.addGrpBx.ResumeLayout(false);
            this.addGrpBx.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuItemGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox maintainGrp;
        private System.Windows.Forms.Label menuLbl;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label searchLbl;
        private System.Windows.Forms.GroupBox addGrpBx;
        private System.Windows.Forms.DataGridView menuItemGrid;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button changeBtn;
        private System.Windows.Forms.Button homeBtn;
        private System.Windows.Forms.MaskedTextBox priceTxt;
        private System.Windows.Forms.Label foodPrice;
        private System.Windows.Forms.MaskedTextBox quantTxtBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox foodTxt;
        private System.Windows.Forms.Label foodName;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox searchTxtBox;
    }
}