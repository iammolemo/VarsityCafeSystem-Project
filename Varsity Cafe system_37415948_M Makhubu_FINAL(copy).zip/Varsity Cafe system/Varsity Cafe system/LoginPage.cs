﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Varsity_cafe_system
{
    public partial class LoginPage : Form
    {
        SqlConnection con;
        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
        SqlCommand cmd;
        SqlDataReader myReader;
        public LoginPage()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage admin = new adminPage();
            admin.ShowDialog();
        }

        private void registerBtn_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(conString);
                con.Open();
                if (txtUserName.Text != "" && txtPasswordLog.Text != "")
                {

                    string pass = txtPasswordLog.Text;
                    string userNameAdmin = txtUserName.Text.ToLower();

                    string query = "SELECT * from [EMPLOYEE] WHERE Empl_Username ='" + txtUserName.Text + "' AND Empl_Password ='" + pass + "'";

                    if (txtPasswordLog.Text == pass)
                    {
                        cmd = new SqlCommand(query, con);
                        myReader = cmd.ExecuteReader();
                        if (myReader.HasRows)
                        {
                            maintainRequestPage maintain = new maintainRequestPage();
                            maintain.Show(); //show the mainain page
                            myReader.Close();
                            this.Hide();

                        }
                        else
                        {
                            MessageBox.Show("Sorry, Username and password you entered doesn't belong to an account. Please double-check Your details and try again.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("The Username or Password is empty", "Information");
                }
                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}

