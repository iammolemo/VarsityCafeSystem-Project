﻿
namespace Varsity_cafe_system
{
    partial class orderConfirmPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(orderConfirmPage));
            this.confirmGrp = new System.Windows.Forms.GroupBox();
            this.confirmLbl = new System.Windows.Forms.Label();
            this.homeBtn = new System.Windows.Forms.Button();
            this.menuHearderLbl = new System.Windows.Forms.Label();
            this.logoPicBx = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.confirmGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // confirmGrp
            // 
            this.confirmGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.confirmGrp.Controls.Add(this.confirmLbl);
            this.confirmGrp.Location = new System.Drawing.Point(97, 65);
            this.confirmGrp.Name = "confirmGrp";
            this.confirmGrp.Size = new System.Drawing.Size(523, 323);
            this.confirmGrp.TabIndex = 0;
            this.confirmGrp.TabStop = false;
            // 
            // confirmLbl
            // 
            this.confirmLbl.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmLbl.Location = new System.Drawing.Point(92, 63);
            this.confirmLbl.Name = "confirmLbl";
            this.confirmLbl.Size = new System.Drawing.Size(326, 175);
            this.confirmLbl.TabIndex = 0;
            this.confirmLbl.Text = resources.GetString("confirmLbl.Text");
            // 
            // homeBtn
            // 
            this.homeBtn.BackColor = System.Drawing.Color.Red;
            this.homeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.Location = new System.Drawing.Point(25, 418);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Size = new System.Drawing.Size(178, 43);
            this.homeBtn.TabIndex = 1;
            this.homeBtn.Text = "GO TO HOMEPAGE";
            this.homeBtn.UseVisualStyleBackColor = false;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // menuHearderLbl
            // 
            this.menuHearderLbl.AutoSize = true;
            this.menuHearderLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuHearderLbl.Location = new System.Drawing.Point(217, 33);
            this.menuHearderLbl.Name = "menuHearderLbl";
            this.menuHearderLbl.Size = new System.Drawing.Size(265, 29);
            this.menuHearderLbl.TabIndex = 14;
            this.menuHearderLbl.Text = "ORDER CONFIRMATION";
            // 
            // logoPicBx
            // 
            this.logoPicBx.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBx.Image")));
            this.logoPicBx.Location = new System.Drawing.Point(684, 12);
            this.logoPicBx.Name = "logoPicBx";
            this.logoPicBx.Size = new System.Drawing.Size(88, 50);
            this.logoPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBx.TabIndex = 13;
            this.logoPicBx.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(465, 292);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(213, 136);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // orderConfirmPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(815, 490);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuHearderLbl);
            this.Controls.Add(this.homeBtn);
            this.Controls.Add(this.logoPicBx);
            this.Controls.Add(this.confirmGrp);
            this.Name = "orderConfirmPage";
            this.Text = "orderConfirmPage";
            this.confirmGrp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox confirmGrp;
        private System.Windows.Forms.Button homeBtn;
        private System.Windows.Forms.Label menuHearderLbl;
        private System.Windows.Forms.PictureBox logoPicBx;
        private System.Windows.Forms.Label confirmLbl;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}