﻿
namespace Varsity_cafe_system
{
    partial class mainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainMenu));
            this.breakfastPicBx = new System.Windows.Forms.PictureBox();
            this.rollsPicBx = new System.Windows.Forms.PictureBox();
            this.toastPicBx = new System.Windows.Forms.PictureBox();
            this.chipsPicBx = new System.Windows.Forms.PictureBox();
            this.saladPicBx = new System.Windows.Forms.PictureBox();
            this.burgerPicBx = new System.Windows.Forms.PictureBox();
            this.wrapsPicBx = new System.Windows.Forms.PictureBox();
            this.nachosPicBx = new System.Windows.Forms.PictureBox();
            this.bevPicBx = new System.Windows.Forms.PictureBox();
            this.menuLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.VCL = new System.Windows.Forms.PictureBox();
            this.breakfastGrp = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.breakfastPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rollsPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toastPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chipsPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saladPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.burgerPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrapsPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nachosPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bevPicBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VCL)).BeginInit();
            this.breakfastGrp.SuspendLayout();
            this.SuspendLayout();
            // 
            // breakfastPicBx
            // 
            this.breakfastPicBx.Image = ((System.Drawing.Image)(resources.GetObject("breakfastPicBx.Image")));
            this.breakfastPicBx.Location = new System.Drawing.Point(20, 20);
            this.breakfastPicBx.Name = "breakfastPicBx";
            this.breakfastPicBx.Size = new System.Drawing.Size(113, 67);
            this.breakfastPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.breakfastPicBx.TabIndex = 0;
            this.breakfastPicBx.TabStop = false;
            this.breakfastPicBx.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // rollsPicBx
            // 
            this.rollsPicBx.Image = ((System.Drawing.Image)(resources.GetObject("rollsPicBx.Image")));
            this.rollsPicBx.Location = new System.Drawing.Point(297, 20);
            this.rollsPicBx.Name = "rollsPicBx";
            this.rollsPicBx.Size = new System.Drawing.Size(116, 67);
            this.rollsPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rollsPicBx.TabIndex = 1;
            this.rollsPicBx.TabStop = false;
            this.rollsPicBx.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // toastPicBx
            // 
            this.toastPicBx.Image = ((System.Drawing.Image)(resources.GetObject("toastPicBx.Image")));
            this.toastPicBx.Location = new System.Drawing.Point(297, 135);
            this.toastPicBx.Name = "toastPicBx";
            this.toastPicBx.Size = new System.Drawing.Size(116, 67);
            this.toastPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.toastPicBx.TabIndex = 2;
            this.toastPicBx.TabStop = false;
            this.toastPicBx.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // chipsPicBx
            // 
            this.chipsPicBx.Image = ((System.Drawing.Image)(resources.GetObject("chipsPicBx.Image")));
            this.chipsPicBx.Location = new System.Drawing.Point(20, 354);
            this.chipsPicBx.Name = "chipsPicBx";
            this.chipsPicBx.Size = new System.Drawing.Size(113, 59);
            this.chipsPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.chipsPicBx.TabIndex = 3;
            this.chipsPicBx.TabStop = false;
            this.chipsPicBx.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // saladPicBx
            // 
            this.saladPicBx.Image = ((System.Drawing.Image)(resources.GetObject("saladPicBx.Image")));
            this.saladPicBx.Location = new System.Drawing.Point(275, 245);
            this.saladPicBx.Name = "saladPicBx";
            this.saladPicBx.Size = new System.Drawing.Size(171, 62);
            this.saladPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.saladPicBx.TabIndex = 4;
            this.saladPicBx.TabStop = false;
            this.saladPicBx.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // burgerPicBx
            // 
            this.burgerPicBx.Image = ((System.Drawing.Image)(resources.GetObject("burgerPicBx.Image")));
            this.burgerPicBx.Location = new System.Drawing.Point(20, 135);
            this.burgerPicBx.Name = "burgerPicBx";
            this.burgerPicBx.Size = new System.Drawing.Size(113, 67);
            this.burgerPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.burgerPicBx.TabIndex = 5;
            this.burgerPicBx.TabStop = false;
            this.burgerPicBx.Click += new System.EventHandler(this.burgerPicBox);
            // 
            // wrapsPicBx
            // 
            this.wrapsPicBx.Image = ((System.Drawing.Image)(resources.GetObject("wrapsPicBx.Image")));
            this.wrapsPicBx.Location = new System.Drawing.Point(20, 245);
            this.wrapsPicBx.Name = "wrapsPicBx";
            this.wrapsPicBx.Size = new System.Drawing.Size(113, 67);
            this.wrapsPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wrapsPicBx.TabIndex = 6;
            this.wrapsPicBx.TabStop = false;
            this.wrapsPicBx.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // nachosPicBx
            // 
            this.nachosPicBx.Image = ((System.Drawing.Image)(resources.GetObject("nachosPicBx.Image")));
            this.nachosPicBx.Location = new System.Drawing.Point(136, 433);
            this.nachosPicBx.Name = "nachosPicBx";
            this.nachosPicBx.Size = new System.Drawing.Size(192, 58);
            this.nachosPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nachosPicBx.TabIndex = 7;
            this.nachosPicBx.TabStop = false;
            this.nachosPicBx.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // bevPicBx
            // 
            this.bevPicBx.Image = ((System.Drawing.Image)(resources.GetObject("bevPicBx.Image")));
            this.bevPicBx.Location = new System.Drawing.Point(297, 354);
            this.bevPicBx.Name = "bevPicBx";
            this.bevPicBx.Size = new System.Drawing.Size(127, 59);
            this.bevPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bevPicBx.TabIndex = 8;
            this.bevPicBx.TabStop = false;
            this.bevPicBx.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // menuLbl
            // 
            this.menuLbl.AutoSize = true;
            this.menuLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuLbl.Location = new System.Drawing.Point(367, 19);
            this.menuLbl.Name = "menuLbl";
            this.menuLbl.Size = new System.Drawing.Size(144, 29);
            this.menuLbl.TabIndex = 9;
            this.menuLbl.Text = "MAIN MENU";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(192, 494);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 14);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nachos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 14);
            this.label3.TabIndex = 11;
            this.label3.Text = "BREAKFAST";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(310, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 14);
            this.label4.TabIndex = 12;
            this.label4.Text = "RUSSIAN ROLLS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 14);
            this.label5.TabIndex = 13;
            this.label5.Text = "BURGER AND CHIPS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(326, 205);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 14);
            this.label6.TabIndex = 14;
            this.label6.Text = "TOASTIES";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 310);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 14);
            this.label7.TabIndex = 15;
            this.label7.Text = "WRAPS AND QUESADILLAS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(326, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 14);
            this.label8.TabIndex = 16;
            this.label8.Text = "SALADS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(44, 416);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 14);
            this.label9.TabIndex = 17;
            this.label9.Text = "CHIPS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(326, 416);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 14);
            this.label10.TabIndex = 18;
            this.label10.Text = "BEVERAGES";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(33, 637);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 40);
            this.button1.TabIndex = 19;
            this.button1.Text = "RETURN TO PREVIOUS PAGE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // VCL
            // 
            this.VCL.Image = ((System.Drawing.Image)(resources.GetObject("VCL.Image")));
            this.VCL.Location = new System.Drawing.Point(790, 9);
            this.VCL.Name = "VCL";
            this.VCL.Size = new System.Drawing.Size(82, 49);
            this.VCL.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.VCL.TabIndex = 20;
            this.VCL.TabStop = false;
            // 
            // breakfastGrp
            // 
            this.breakfastGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.breakfastGrp.Controls.Add(this.label6);
            this.breakfastGrp.Controls.Add(this.breakfastPicBx);
            this.breakfastGrp.Controls.Add(this.label3);
            this.breakfastGrp.Controls.Add(this.label2);
            this.breakfastGrp.Controls.Add(this.label10);
            this.breakfastGrp.Controls.Add(this.label4);
            this.breakfastGrp.Controls.Add(this.nachosPicBx);
            this.breakfastGrp.Controls.Add(this.label8);
            this.breakfastGrp.Controls.Add(this.burgerPicBx);
            this.breakfastGrp.Controls.Add(this.bevPicBx);
            this.breakfastGrp.Controls.Add(this.label5);
            this.breakfastGrp.Controls.Add(this.wrapsPicBx);
            this.breakfastGrp.Controls.Add(this.label7);
            this.breakfastGrp.Controls.Add(this.label9);
            this.breakfastGrp.Controls.Add(this.saladPicBx);
            this.breakfastGrp.Controls.Add(this.chipsPicBx);
            this.breakfastGrp.Controls.Add(this.rollsPicBx);
            this.breakfastGrp.Controls.Add(this.toastPicBx);
            this.breakfastGrp.Location = new System.Drawing.Point(220, 66);
            this.breakfastGrp.Name = "breakfastGrp";
            this.breakfastGrp.Size = new System.Drawing.Size(469, 534);
            this.breakfastGrp.TabIndex = 21;
            this.breakfastGrp.TabStop = false;
            this.breakfastGrp.Text = "breakfastGrp";
            // 
            // mainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(884, 692);
            this.Controls.Add(this.breakfastGrp);
            this.Controls.Add(this.VCL);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuLbl);
            this.Name = "mainMenu";
            this.Text = "mainMenu";
            ((System.ComponentModel.ISupportInitialize)(this.breakfastPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rollsPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toastPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chipsPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saladPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.burgerPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrapsPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nachosPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bevPicBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VCL)).EndInit();
            this.breakfastGrp.ResumeLayout(false);
            this.breakfastGrp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox breakfastPicBx;
        private System.Windows.Forms.PictureBox rollsPicBx;
        private System.Windows.Forms.PictureBox toastPicBx;
        private System.Windows.Forms.PictureBox chipsPicBx;
        private System.Windows.Forms.PictureBox saladPicBx;
        private System.Windows.Forms.PictureBox burgerPicBx;
        private System.Windows.Forms.PictureBox wrapsPicBx;
        private System.Windows.Forms.PictureBox nachosPicBx;
        private System.Windows.Forms.PictureBox bevPicBx;
        private System.Windows.Forms.Label menuLbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox VCL;
        private System.Windows.Forms.GroupBox breakfastGrp;
    }
}