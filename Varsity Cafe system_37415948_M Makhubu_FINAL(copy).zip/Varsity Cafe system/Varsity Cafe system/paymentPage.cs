﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varsity_cafe_system
{
    public partial class paymentPage : Form
    {
        public paymentPage()
        {
            InitializeComponent();
        }

        private void counterBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            orderConfirmPage confirm = new orderConfirmPage();
            confirm.ShowDialog();
        }

        private void payHereBtn_Click(object sender, EventArgs e)
        {
            payHereBtn.Visible = false;
            paymentMethLbl.Visible = false;
            counterBtn.Visible = false;
            cardTypeLbl.Visible = true;
            cardCombo.Visible = true;
        }

        private void HideButtons()
        {
            bankLbl.Visible = false;
            nedbankBtn.Visible = false;
            capitecBtn.Visible = false;
            standardBtn.Visible = false;
            fnbBtn.Visible = false;
            absaBtn.Visible = false;
        }

        private void cardCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cardCombo.SelectedIndex==0 || cardCombo.SelectedIndex == 1|| cardCombo.SelectedIndex == 2)
            {
                bankLbl.Visible = true;
                nedbankBtn.Visible = true;
                capitecBtn.Visible = true;
                standardBtn.Visible = true;
                fnbBtn.Visible = true;
                absaBtn.Visible = true;
                
            }

            
        }
        private void HideCardType()
        {
            cardTypeLbl.Visible = false;
            cardCombo.Visible = false;
        }
        private void ShowPinDetails()
        {
            pinLbl.Visible = true;
            pinTxtBx.Visible = true;
            oneBtn.Visible = true;
            twoBtn.Visible = true;
            threeeBtn.Visible = true;
            fourBtn.Visible = true;
            fiveBtn.Visible = true;
            sixBtn.Visible = true;
            sevBtn.Visible = true;
            eightBtn.Visible = true;
            nineBtn.Visible = true;
            zeroBtn.Visible = true;
            okBtn.Visible = true;
        }

        private void nedbankBtn_Click(object sender, EventArgs e)
        {
            HideButtons();
            ShowPinDetails();
            HideCardType();


        }

        private void capitecBtn_Click(object sender, EventArgs e)
        {
            HideButtons();
            ShowPinDetails();
            HideCardType();
        }

        private void standardBtn_Click(object sender, EventArgs e)
        {
            HideButtons();
            ShowPinDetails();
            HideCardType();
        }

        private void fnbBtn_Click(object sender, EventArgs e)
        {
            HideButtons();
            ShowPinDetails();
            HideCardType();
        }

        private void absaBtn_Click(object sender, EventArgs e)
        {
            HideButtons();
            ShowPinDetails();
            HideCardType();
        }

        private void okBtn_Click(object sender, EventArgs e)
        {
            if (pinTxtBx.Text == "")
            {
                MessageBox.Show("Please enter your card's pin in order for your payment to be authorized and processed");
            }
            else
            {
                this.Hide();
                orderConfirmPage confirm = new orderConfirmPage();
                confirm.ShowDialog();
            }
                
            

            
        }
    }
}
