﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Varsity_cafe_system
{
    public partial class employeesPage : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        DataSet ds;
        string conString = @"Data Source=LAPTOP-06TKCTJN\SQLEXPRESS;Initial Catalog=VarsityCafeDB;Integrated Security=True";
        public employeesPage()
        {
            InitializeComponent();
        }

        private void employeesPage_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(conString);
            con.Open();
            string sql = "SELECT * FROM EMPLOYEE";
            cmd = new SqlCommand(sql, con);
            adap = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adap.Fill(ds, "EMPLOYEE");
            emplGrid.DataSource = ds.Tables["EMPLOYEE"].DefaultView;
            con.Close();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (MessageBox.Show("Are you sure you want to delete the selected employee?","Delete record",MessageBoxButtons.YesNo)==DialogResult.Yes)
                {
                    int rowIndex = emplGrid.CurrentCell.RowIndex;
                    emplGrid.Rows.RemoveAt(rowIndex);
                }
                else
                {
                    MessageBox.Show("You have not selected a record to be deleted, Please make sure you do in order to proceed");
                }
                
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void searchTxtBx_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            

        }

        private void searchTxtBx_TextChanged(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintainRequestPage request = new maintainRequestPage();
            request.ShowDialog();
        }

        private void homeBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            homePage home = new homePage();
            home.ShowDialog();
        }

        private void searchTxtBx_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void searchTxtBx_MaskInputRejected_1(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void searchTxtBox_TextChanged(object sender, EventArgs e)
        {
            con = new SqlConnection(conString);
            con.Open();
            string sql = $"SELECT * FROM EMPLOYEE WHERE Empl_FName LIKE '{searchTxtBox.Text}%'";
            cmd = new SqlCommand(sql, con);
            adap = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adap.Fill(ds, "EMPLOYEE");
            emplGrid.DataSource = ds.Tables["EMPLOYEE"].DefaultView;
            con.Close();
        }

        private void changeBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
