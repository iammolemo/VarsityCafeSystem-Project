﻿
namespace Varsity_cafe_system
{
    partial class paymentPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(paymentPage));
            this.paymentGrp = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuHearderLbl = new System.Windows.Forms.Label();
            this.payHereBtn = new System.Windows.Forms.Button();
            this.counterBtn = new System.Windows.Forms.Button();
            this.nedbankBtn = new System.Windows.Forms.Button();
            this.capitecBtn = new System.Windows.Forms.Button();
            this.standardBtn = new System.Windows.Forms.Button();
            this.fnbBtn = new System.Windows.Forms.Button();
            this.absaBtn = new System.Windows.Forms.Button();
            this.okBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.sevBtn = new System.Windows.Forms.Button();
            this.threeeBtn = new System.Windows.Forms.Button();
            this.twoBtn = new System.Windows.Forms.Button();
            this.oneBtn = new System.Windows.Forms.Button();
            this.sixBtn = new System.Windows.Forms.Button();
            this.fiveBtn = new System.Windows.Forms.Button();
            this.fourBtn = new System.Windows.Forms.Button();
            this.nineBtn = new System.Windows.Forms.Button();
            this.eightBtn = new System.Windows.Forms.Button();
            this.zeroBtn = new System.Windows.Forms.Button();
            this.paymentMethLbl = new System.Windows.Forms.Label();
            this.pinTxtBx = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.cardTypeLbl = new System.Windows.Forms.Label();
            this.bankLbl = new System.Windows.Forms.Label();
            this.totalLbl = new System.Windows.Forms.Label();
            this.pinLbl = new System.Windows.Forms.Label();
            this.cardCombo = new System.Windows.Forms.ComboBox();
            this.paymentGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // paymentGrp
            // 
            this.paymentGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.paymentGrp.Controls.Add(this.cardCombo);
            this.paymentGrp.Controls.Add(this.pinLbl);
            this.paymentGrp.Controls.Add(this.totalLbl);
            this.paymentGrp.Controls.Add(this.bankLbl);
            this.paymentGrp.Controls.Add(this.cardTypeLbl);
            this.paymentGrp.Controls.Add(this.pictureBox2);
            this.paymentGrp.Controls.Add(this.pinTxtBx);
            this.paymentGrp.Controls.Add(this.paymentMethLbl);
            this.paymentGrp.Controls.Add(this.zeroBtn);
            this.paymentGrp.Controls.Add(this.eightBtn);
            this.paymentGrp.Controls.Add(this.nineBtn);
            this.paymentGrp.Controls.Add(this.fourBtn);
            this.paymentGrp.Controls.Add(this.fiveBtn);
            this.paymentGrp.Controls.Add(this.sixBtn);
            this.paymentGrp.Controls.Add(this.oneBtn);
            this.paymentGrp.Controls.Add(this.twoBtn);
            this.paymentGrp.Controls.Add(this.threeeBtn);
            this.paymentGrp.Controls.Add(this.sevBtn);
            this.paymentGrp.Controls.Add(this.okBtn);
            this.paymentGrp.Controls.Add(this.absaBtn);
            this.paymentGrp.Controls.Add(this.fnbBtn);
            this.paymentGrp.Controls.Add(this.standardBtn);
            this.paymentGrp.Controls.Add(this.capitecBtn);
            this.paymentGrp.Controls.Add(this.nedbankBtn);
            this.paymentGrp.Controls.Add(this.counterBtn);
            this.paymentGrp.Controls.Add(this.payHereBtn);
            this.paymentGrp.Location = new System.Drawing.Point(99, 82);
            this.paymentGrp.Name = "paymentGrp";
            this.paymentGrp.Size = new System.Drawing.Size(692, 559);
            this.paymentGrp.TabIndex = 0;
            this.paymentGrp.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(770, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // menuHearderLbl
            // 
            this.menuHearderLbl.AutoSize = true;
            this.menuHearderLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuHearderLbl.Location = new System.Drawing.Point(310, 33);
            this.menuHearderLbl.Name = "menuHearderLbl";
            this.menuHearderLbl.Size = new System.Drawing.Size(268, 29);
            this.menuHearderLbl.TabIndex = 12;
            this.menuHearderLbl.Text = "PAYMENT PROCESSING";
            // 
            // payHereBtn
            // 
            this.payHereBtn.BackColor = System.Drawing.Color.Red;
            this.payHereBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payHereBtn.Location = new System.Drawing.Point(135, 61);
            this.payHereBtn.Name = "payHereBtn";
            this.payHereBtn.Size = new System.Drawing.Size(134, 40);
            this.payHereBtn.TabIndex = 0;
            this.payHereBtn.Text = "PAY HERE";
            this.payHereBtn.UseVisualStyleBackColor = false;
            this.payHereBtn.Click += new System.EventHandler(this.payHereBtn_Click);
            // 
            // counterBtn
            // 
            this.counterBtn.BackColor = System.Drawing.Color.Red;
            this.counterBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.counterBtn.Location = new System.Drawing.Point(377, 61);
            this.counterBtn.Name = "counterBtn";
            this.counterBtn.Size = new System.Drawing.Size(136, 40);
            this.counterBtn.TabIndex = 1;
            this.counterBtn.Text = "PAY AT THE COUNTER";
            this.counterBtn.UseVisualStyleBackColor = false;
            this.counterBtn.Click += new System.EventHandler(this.counterBtn_Click);
            // 
            // nedbankBtn
            // 
            this.nedbankBtn.BackColor = System.Drawing.Color.Red;
            this.nedbankBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nedbankBtn.Location = new System.Drawing.Point(61, 242);
            this.nedbankBtn.Name = "nedbankBtn";
            this.nedbankBtn.Size = new System.Drawing.Size(93, 44);
            this.nedbankBtn.TabIndex = 2;
            this.nedbankBtn.Text = "NEDBANK";
            this.nedbankBtn.UseVisualStyleBackColor = false;
            this.nedbankBtn.Visible = false;
            this.nedbankBtn.Click += new System.EventHandler(this.nedbankBtn_Click);
            // 
            // capitecBtn
            // 
            this.capitecBtn.BackColor = System.Drawing.Color.Red;
            this.capitecBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capitecBtn.Location = new System.Drawing.Point(176, 242);
            this.capitecBtn.Name = "capitecBtn";
            this.capitecBtn.Size = new System.Drawing.Size(93, 44);
            this.capitecBtn.TabIndex = 3;
            this.capitecBtn.Text = "CAPITEC";
            this.capitecBtn.UseVisualStyleBackColor = false;
            this.capitecBtn.Visible = false;
            this.capitecBtn.Click += new System.EventHandler(this.capitecBtn_Click);
            // 
            // standardBtn
            // 
            this.standardBtn.BackColor = System.Drawing.Color.Red;
            this.standardBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.standardBtn.Location = new System.Drawing.Point(299, 242);
            this.standardBtn.Name = "standardBtn";
            this.standardBtn.Size = new System.Drawing.Size(104, 44);
            this.standardBtn.TabIndex = 4;
            this.standardBtn.Text = "STANDARD BANK";
            this.standardBtn.UseVisualStyleBackColor = false;
            this.standardBtn.Visible = false;
            this.standardBtn.Click += new System.EventHandler(this.standardBtn_Click);
            // 
            // fnbBtn
            // 
            this.fnbBtn.BackColor = System.Drawing.Color.Red;
            this.fnbBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnbBtn.Location = new System.Drawing.Point(420, 242);
            this.fnbBtn.Name = "fnbBtn";
            this.fnbBtn.Size = new System.Drawing.Size(93, 44);
            this.fnbBtn.TabIndex = 5;
            this.fnbBtn.Text = "FNB";
            this.fnbBtn.UseVisualStyleBackColor = false;
            this.fnbBtn.Visible = false;
            this.fnbBtn.Click += new System.EventHandler(this.fnbBtn_Click);
            // 
            // absaBtn
            // 
            this.absaBtn.BackColor = System.Drawing.Color.Red;
            this.absaBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.absaBtn.Location = new System.Drawing.Point(522, 242);
            this.absaBtn.Name = "absaBtn";
            this.absaBtn.Size = new System.Drawing.Size(93, 44);
            this.absaBtn.TabIndex = 6;
            this.absaBtn.Text = "ABSA BANK";
            this.absaBtn.UseVisualStyleBackColor = false;
            this.absaBtn.Visible = false;
            this.absaBtn.Click += new System.EventHandler(this.absaBtn_Click);
            // 
            // okBtn
            // 
            this.okBtn.BackColor = System.Drawing.Color.Red;
            this.okBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.okBtn.Location = new System.Drawing.Point(265, 518);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 41);
            this.okBtn.TabIndex = 7;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = false;
            this.okBtn.Visible = false;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 647);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(189, 43);
            this.backBtn.TabIndex = 8;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            // 
            // sevBtn
            // 
            this.sevBtn.BackColor = System.Drawing.Color.DimGray;
            this.sevBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevBtn.Location = new System.Drawing.Point(216, 439);
            this.sevBtn.Name = "sevBtn";
            this.sevBtn.Size = new System.Drawing.Size(42, 29);
            this.sevBtn.TabIndex = 13;
            this.sevBtn.Text = "7";
            this.sevBtn.UseVisualStyleBackColor = false;
            this.sevBtn.Visible = false;
            // 
            // threeeBtn
            // 
            this.threeeBtn.BackColor = System.Drawing.Color.DimGray;
            this.threeeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeeBtn.Location = new System.Drawing.Point(349, 369);
            this.threeeBtn.Name = "threeeBtn";
            this.threeeBtn.Size = new System.Drawing.Size(42, 29);
            this.threeeBtn.TabIndex = 14;
            this.threeeBtn.Text = "3";
            this.threeeBtn.UseVisualStyleBackColor = false;
            this.threeeBtn.Visible = false;
            // 
            // twoBtn
            // 
            this.twoBtn.BackColor = System.Drawing.Color.DimGray;
            this.twoBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoBtn.Location = new System.Drawing.Point(282, 369);
            this.twoBtn.Name = "twoBtn";
            this.twoBtn.Size = new System.Drawing.Size(42, 29);
            this.twoBtn.TabIndex = 15;
            this.twoBtn.Text = "2";
            this.twoBtn.UseVisualStyleBackColor = false;
            this.twoBtn.Visible = false;
            // 
            // oneBtn
            // 
            this.oneBtn.BackColor = System.Drawing.Color.DimGray;
            this.oneBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneBtn.Location = new System.Drawing.Point(216, 369);
            this.oneBtn.Name = "oneBtn";
            this.oneBtn.Size = new System.Drawing.Size(42, 29);
            this.oneBtn.TabIndex = 16;
            this.oneBtn.Text = "1";
            this.oneBtn.UseVisualStyleBackColor = false;
            this.oneBtn.Visible = false;
            // 
            // sixBtn
            // 
            this.sixBtn.BackColor = System.Drawing.Color.DimGray;
            this.sixBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixBtn.Location = new System.Drawing.Point(349, 404);
            this.sixBtn.Name = "sixBtn";
            this.sixBtn.Size = new System.Drawing.Size(42, 29);
            this.sixBtn.TabIndex = 17;
            this.sixBtn.Text = "6";
            this.sixBtn.UseVisualStyleBackColor = false;
            this.sixBtn.Visible = false;
            // 
            // fiveBtn
            // 
            this.fiveBtn.BackColor = System.Drawing.Color.DimGray;
            this.fiveBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fiveBtn.Location = new System.Drawing.Point(282, 404);
            this.fiveBtn.Name = "fiveBtn";
            this.fiveBtn.Size = new System.Drawing.Size(42, 29);
            this.fiveBtn.TabIndex = 18;
            this.fiveBtn.Text = "5";
            this.fiveBtn.UseVisualStyleBackColor = false;
            this.fiveBtn.Visible = false;
            // 
            // fourBtn
            // 
            this.fourBtn.BackColor = System.Drawing.Color.DimGray;
            this.fourBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourBtn.Location = new System.Drawing.Point(216, 404);
            this.fourBtn.Name = "fourBtn";
            this.fourBtn.Size = new System.Drawing.Size(42, 29);
            this.fourBtn.TabIndex = 19;
            this.fourBtn.Text = "4";
            this.fourBtn.UseVisualStyleBackColor = false;
            this.fourBtn.Visible = false;
            // 
            // nineBtn
            // 
            this.nineBtn.BackColor = System.Drawing.Color.DimGray;
            this.nineBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nineBtn.Location = new System.Drawing.Point(349, 439);
            this.nineBtn.Name = "nineBtn";
            this.nineBtn.Size = new System.Drawing.Size(42, 29);
            this.nineBtn.TabIndex = 20;
            this.nineBtn.Text = "9";
            this.nineBtn.UseVisualStyleBackColor = false;
            this.nineBtn.Visible = false;
            // 
            // eightBtn
            // 
            this.eightBtn.BackColor = System.Drawing.Color.DimGray;
            this.eightBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightBtn.Location = new System.Drawing.Point(282, 439);
            this.eightBtn.Name = "eightBtn";
            this.eightBtn.Size = new System.Drawing.Size(42, 29);
            this.eightBtn.TabIndex = 21;
            this.eightBtn.Text = "8";
            this.eightBtn.UseVisualStyleBackColor = false;
            this.eightBtn.Visible = false;
            // 
            // zeroBtn
            // 
            this.zeroBtn.BackColor = System.Drawing.Color.DimGray;
            this.zeroBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zeroBtn.Location = new System.Drawing.Point(282, 483);
            this.zeroBtn.Name = "zeroBtn";
            this.zeroBtn.Size = new System.Drawing.Size(42, 29);
            this.zeroBtn.TabIndex = 22;
            this.zeroBtn.Text = "0";
            this.zeroBtn.UseVisualStyleBackColor = false;
            this.zeroBtn.Visible = false;
            // 
            // paymentMethLbl
            // 
            this.paymentMethLbl.AutoSize = true;
            this.paymentMethLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentMethLbl.Location = new System.Drawing.Point(192, 28);
            this.paymentMethLbl.Name = "paymentMethLbl";
            this.paymentMethLbl.Size = new System.Drawing.Size(287, 16);
            this.paymentMethLbl.TabIndex = 23;
            this.paymentMethLbl.Text = "PLEASE CHOOSE HOW YOU WOULD LIKE TO  PAY:";
            // 
            // pinTxtBx
            // 
            this.pinTxtBx.Location = new System.Drawing.Point(289, 329);
            this.pinTxtBx.Name = "pinTxtBx";
            this.pinTxtBx.Size = new System.Drawing.Size(121, 20);
            this.pinTxtBx.TabIndex = 24;
            this.pinTxtBx.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(6, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 25);
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // cardTypeLbl
            // 
            this.cardTypeLbl.AutoSize = true;
            this.cardTypeLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardTypeLbl.Location = new System.Drawing.Point(58, 138);
            this.cardTypeLbl.Name = "cardTypeLbl";
            this.cardTypeLbl.Size = new System.Drawing.Size(174, 16);
            this.cardTypeLbl.TabIndex = 26;
            this.cardTypeLbl.Text = "Please select your card type:";
            this.cardTypeLbl.Visible = false;
            // 
            // bankLbl
            // 
            this.bankLbl.AutoSize = true;
            this.bankLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bankLbl.Location = new System.Drawing.Point(296, 210);
            this.bankLbl.Name = "bankLbl";
            this.bankLbl.Size = new System.Drawing.Size(176, 16);
            this.bankLbl.TabIndex = 27;
            this.bankLbl.Text = "PLEASE SELECT YOUR BANK:";
            this.bankLbl.Visible = false;
            // 
            // totalLbl
            // 
            this.totalLbl.AutoSize = true;
            this.totalLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLbl.Location = new System.Drawing.Point(45, 0);
            this.totalLbl.Name = "totalLbl";
            this.totalLbl.Size = new System.Drawing.Size(163, 16);
            this.totalLbl.TabIndex = 28;
            this.totalLbl.Text = "Your order made a total of: ";
            // 
            // pinLbl
            // 
            this.pinLbl.AutoSize = true;
            this.pinLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pinLbl.Location = new System.Drawing.Point(173, 330);
            this.pinLbl.Name = "pinLbl";
            this.pinLbl.Size = new System.Drawing.Size(110, 16);
            this.pinLbl.TabIndex = 29;
            this.pinLbl.Text = "ENTER YOUR PIN:";
            this.pinLbl.Visible = false;
            // 
            // cardCombo
            // 
            this.cardCombo.FormattingEnabled = true;
            this.cardCombo.Items.AddRange(new object[] {
            "Master Card",
            "Visa Card",
            "Debit Card"});
            this.cardCombo.Location = new System.Drawing.Point(61, 169);
            this.cardCombo.Name = "cardCombo";
            this.cardCombo.Size = new System.Drawing.Size(121, 21);
            this.cardCombo.TabIndex = 30;
            this.cardCombo.Visible = false;
            this.cardCombo.SelectedIndexChanged += new System.EventHandler(this.cardCombo_SelectedIndexChanged);
            // 
            // paymentPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(870, 702);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.menuHearderLbl);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.paymentGrp);
            this.Name = "paymentPage";
            this.Text = "paymentPage";
            this.paymentGrp.ResumeLayout(false);
            this.paymentGrp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox paymentGrp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label menuHearderLbl;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button absaBtn;
        private System.Windows.Forms.Button fnbBtn;
        private System.Windows.Forms.Button standardBtn;
        private System.Windows.Forms.Button capitecBtn;
        private System.Windows.Forms.Button nedbankBtn;
        private System.Windows.Forms.Button counterBtn;
        private System.Windows.Forms.Button payHereBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button sevBtn;
        private System.Windows.Forms.Button zeroBtn;
        private System.Windows.Forms.Button eightBtn;
        private System.Windows.Forms.Button nineBtn;
        private System.Windows.Forms.Button fourBtn;
        private System.Windows.Forms.Button fiveBtn;
        private System.Windows.Forms.Button sixBtn;
        private System.Windows.Forms.Button oneBtn;
        private System.Windows.Forms.Button twoBtn;
        private System.Windows.Forms.Button threeeBtn;
        private System.Windows.Forms.Label pinLbl;
        private System.Windows.Forms.Label totalLbl;
        private System.Windows.Forms.Label bankLbl;
        private System.Windows.Forms.Label cardTypeLbl;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox pinTxtBx;
        private System.Windows.Forms.Label paymentMethLbl;
        private System.Windows.Forms.ComboBox cardCombo;
    }
}