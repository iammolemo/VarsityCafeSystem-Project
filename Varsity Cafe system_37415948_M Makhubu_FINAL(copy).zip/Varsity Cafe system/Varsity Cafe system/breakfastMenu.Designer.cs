﻿
namespace Varsity_cafe_system
{
    partial class breakfastMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(breakfastMenu));
            this.logoPicBx = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.menuHearderLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.breakfastQuesBtn = new System.Windows.Forms.Button();
            this.baconBtn = new System.Windows.Forms.Button();
            this.toastedBaconBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // logoPicBx
            // 
            this.logoPicBx.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBx.Image")));
            this.logoPicBx.Location = new System.Drawing.Point(791, 12);
            this.logoPicBx.Name = "logoPicBx";
            this.logoPicBx.Size = new System.Drawing.Size(70, 44);
            this.logoPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBx.TabIndex = 0;
            this.logoPicBx.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.toastedBaconBtn);
            this.groupBox1.Controls.Add(this.baconBtn);
            this.groupBox1.Controls.Add(this.breakfastQuesBtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(153, 87);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(515, 309);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 470);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(195, 39);
            this.button1.TabIndex = 2;
            this.button1.Text = "RETURN TO PREVIOUS PAGE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuHearderLbl
            // 
            this.menuHearderLbl.AutoSize = true;
            this.menuHearderLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuHearderLbl.Location = new System.Drawing.Point(304, 44);
            this.menuHearderLbl.Name = "menuHearderLbl";
            this.menuHearderLbl.Size = new System.Drawing.Size(215, 29);
            this.menuHearderLbl.TabIndex = 3;
            this.menuHearderLbl.Text = "BREAKFAST MENU";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(73, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "BREAKFAST QUESADILLA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "BACON, EGG AND CHEDDAR WRAP";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(73, 252);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(228, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "TOASTED BACON AND EGG SANDWICH";
            // 
            // breakfastQuesBtn
            // 
            this.breakfastQuesBtn.BackColor = System.Drawing.Color.Red;
            this.breakfastQuesBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfastQuesBtn.Location = new System.Drawing.Point(349, 62);
            this.breakfastQuesBtn.Name = "breakfastQuesBtn";
            this.breakfastQuesBtn.Size = new System.Drawing.Size(121, 35);
            this.breakfastQuesBtn.TabIndex = 3;
            this.breakfastQuesBtn.Text = "R45";
            this.breakfastQuesBtn.UseVisualStyleBackColor = false;
            this.breakfastQuesBtn.Click += new System.EventHandler(this.breakfastQuesBtn_Click);
            // 
            // baconBtn
            // 
            this.baconBtn.BackColor = System.Drawing.Color.Red;
            this.baconBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baconBtn.Location = new System.Drawing.Point(349, 147);
            this.baconBtn.Name = "baconBtn";
            this.baconBtn.Size = new System.Drawing.Size(121, 35);
            this.baconBtn.TabIndex = 4;
            this.baconBtn.Text = "R49";
            this.baconBtn.UseVisualStyleBackColor = false;
            this.baconBtn.Click += new System.EventHandler(this.baconBtn_Click);
            // 
            // toastedBaconBtn
            // 
            this.toastedBaconBtn.BackColor = System.Drawing.Color.Red;
            this.toastedBaconBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toastedBaconBtn.Location = new System.Drawing.Point(349, 241);
            this.toastedBaconBtn.Name = "toastedBaconBtn";
            this.toastedBaconBtn.Size = new System.Drawing.Size(121, 38);
            this.toastedBaconBtn.TabIndex = 5;
            this.toastedBaconBtn.Text = "R62";
            this.toastedBaconBtn.UseVisualStyleBackColor = false;
            this.toastedBaconBtn.Click += new System.EventHandler(this.toastedBaconBtn_Click);
            // 
            // breakfastMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(874, 522);
            this.Controls.Add(this.menuHearderLbl);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.logoPicBx);
            this.Name = "breakfastMenu";
            this.Text = "breakfastMenu";
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logoPicBx;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button toastedBaconBtn;
        private System.Windows.Forms.Button baconBtn;
        private System.Windows.Forms.Button breakfastQuesBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label menuHearderLbl;
    }
}