﻿
namespace Varsity_cafe_system
{
    partial class registerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(registerPage));
            this.backBtn = new System.Windows.Forms.Button();
            this.deleteGrp = new System.Windows.Forms.GroupBox();
            this.idNotxtBox = new System.Windows.Forms.TextBox();
            this.emailLbl = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.idNoLbl = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.confirmPassLbl = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.confirmEmailLbl = new System.Windows.Forms.Label();
            this.txtConfirmEmail = new System.Windows.Forms.TextBox();
            this.passLbl = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.usernameLbl = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lNameLbl = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.fNameLbl = new System.Windows.Forms.Label();
            this.registerBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.headerLbl = new System.Windows.Forms.Label();
            this.loginGrp = new System.Windows.Forms.GroupBox();
            this.regLbl = new System.Windows.Forms.Label();
            this.loginBtn = new System.Windows.Forms.Button();
            this.txtCellNo = new System.Windows.Forms.TextBox();
            this.cellNoLbl = new System.Windows.Forms.Label();
            this.deleteGrp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.loginGrp.SuspendLayout();
            this.SuspendLayout();
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 667);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(183, 44);
            this.backBtn.TabIndex = 11;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // deleteGrp
            // 
            this.deleteGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.deleteGrp.Controls.Add(this.txtCellNo);
            this.deleteGrp.Controls.Add(this.cellNoLbl);
            this.deleteGrp.Controls.Add(this.idNotxtBox);
            this.deleteGrp.Controls.Add(this.emailLbl);
            this.deleteGrp.Controls.Add(this.txtEmail);
            this.deleteGrp.Controls.Add(this.idNoLbl);
            this.deleteGrp.Controls.Add(this.txtUserName);
            this.deleteGrp.Controls.Add(this.confirmPassLbl);
            this.deleteGrp.Controls.Add(this.txtConfirmPassword);
            this.deleteGrp.Controls.Add(this.confirmEmailLbl);
            this.deleteGrp.Controls.Add(this.txtConfirmEmail);
            this.deleteGrp.Controls.Add(this.passLbl);
            this.deleteGrp.Controls.Add(this.txtPassword);
            this.deleteGrp.Controls.Add(this.usernameLbl);
            this.deleteGrp.Controls.Add(this.txtFirstName);
            this.deleteGrp.Controls.Add(this.lNameLbl);
            this.deleteGrp.Controls.Add(this.txtLastName);
            this.deleteGrp.Controls.Add(this.fNameLbl);
            this.deleteGrp.Controls.Add(this.registerBtn);
            this.deleteGrp.Location = new System.Drawing.Point(164, 81);
            this.deleteGrp.Name = "deleteGrp";
            this.deleteGrp.Size = new System.Drawing.Size(410, 474);
            this.deleteGrp.TabIndex = 10;
            this.deleteGrp.TabStop = false;
            // 
            // idNotxtBox
            // 
            this.idNotxtBox.Location = new System.Drawing.Point(220, 146);
            this.idNotxtBox.Name = "idNotxtBox";
            this.idNotxtBox.Size = new System.Drawing.Size(134, 20);
            this.idNotxtBox.TabIndex = 18;
            // 
            // emailLbl
            // 
            this.emailLbl.AutoSize = true;
            this.emailLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLbl.Location = new System.Drawing.Point(40, 187);
            this.emailLbl.Name = "emailLbl";
            this.emailLbl.Size = new System.Drawing.Size(109, 16);
            this.emailLbl.TabIndex = 17;
            this.emailLbl.Text = "EMAIL ADDRESS:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(220, 186);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(134, 20);
            this.txtEmail.TabIndex = 16;
            // 
            // idNoLbl
            // 
            this.idNoLbl.AutoSize = true;
            this.idNoLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idNoLbl.Location = new System.Drawing.Point(38, 147);
            this.idNoLbl.Name = "idNoLbl";
            this.idNoLbl.Size = new System.Drawing.Size(79, 16);
            this.idNoLbl.TabIndex = 15;
            this.idNoLbl.Text = "ID NUMBER:";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(220, 296);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(134, 20);
            this.txtUserName.TabIndex = 14;
            // 
            // confirmPassLbl
            // 
            this.confirmPassLbl.AutoSize = true;
            this.confirmPassLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmPassLbl.Location = new System.Drawing.Point(38, 377);
            this.confirmPassLbl.Name = "confirmPassLbl";
            this.confirmPassLbl.Size = new System.Drawing.Size(134, 16);
            this.confirmPassLbl.TabIndex = 13;
            this.confirmPassLbl.Text = "CONFIRM PASSWORD:";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(220, 376);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(134, 20);
            this.txtConfirmPassword.TabIndex = 12;
            // 
            // confirmEmailLbl
            // 
            this.confirmEmailLbl.AutoSize = true;
            this.confirmEmailLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmEmailLbl.Location = new System.Drawing.Point(38, 228);
            this.confirmEmailLbl.Name = "confirmEmailLbl";
            this.confirmEmailLbl.Size = new System.Drawing.Size(166, 16);
            this.confirmEmailLbl.TabIndex = 11;
            this.confirmEmailLbl.Text = "CONFIRM EMAIL ADDRESS:";
            // 
            // txtConfirmEmail
            // 
            this.txtConfirmEmail.Location = new System.Drawing.Point(220, 228);
            this.txtConfirmEmail.Name = "txtConfirmEmail";
            this.txtConfirmEmail.Size = new System.Drawing.Size(134, 20);
            this.txtConfirmEmail.TabIndex = 10;
            // 
            // passLbl
            // 
            this.passLbl.AutoSize = true;
            this.passLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passLbl.Location = new System.Drawing.Point(40, 336);
            this.passLbl.Name = "passLbl";
            this.passLbl.Size = new System.Drawing.Size(77, 16);
            this.passLbl.TabIndex = 9;
            this.passLbl.Text = "PASSWORD:";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(220, 335);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(134, 20);
            this.txtPassword.TabIndex = 8;
            // 
            // usernameLbl
            // 
            this.usernameLbl.AutoSize = true;
            this.usernameLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameLbl.Location = new System.Drawing.Point(38, 297);
            this.usernameLbl.Name = "usernameLbl";
            this.usernameLbl.Size = new System.Drawing.Size(79, 16);
            this.usernameLbl.TabIndex = 7;
            this.usernameLbl.Text = "USERNAME:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(220, 64);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(134, 20);
            this.txtFirstName.TabIndex = 6;
            // 
            // lNameLbl
            // 
            this.lNameLbl.AutoSize = true;
            this.lNameLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lNameLbl.Location = new System.Drawing.Point(40, 105);
            this.lNameLbl.Name = "lNameLbl";
            this.lNameLbl.Size = new System.Drawing.Size(77, 16);
            this.lNameLbl.TabIndex = 5;
            this.lNameLbl.Text = "LAST NAME:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(220, 104);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(134, 20);
            this.txtLastName.TabIndex = 4;
            // 
            // fNameLbl
            // 
            this.fNameLbl.AutoSize = true;
            this.fNameLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fNameLbl.Location = new System.Drawing.Point(38, 65);
            this.fNameLbl.Name = "fNameLbl";
            this.fNameLbl.Size = new System.Drawing.Size(82, 16);
            this.fNameLbl.TabIndex = 3;
            this.fNameLbl.Text = "FIRST NAME:";
            // 
            // registerBtn
            // 
            this.registerBtn.BackColor = System.Drawing.Color.Red;
            this.registerBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registerBtn.Location = new System.Drawing.Point(98, 413);
            this.registerBtn.Name = "registerBtn";
            this.registerBtn.Size = new System.Drawing.Size(202, 46);
            this.registerBtn.TabIndex = 2;
            this.registerBtn.Text = "REGISTER";
            this.registerBtn.UseVisualStyleBackColor = false;
            this.registerBtn.Click += new System.EventHandler(this.registerBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(718, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // headerLbl
            // 
            this.headerLbl.AutoSize = true;
            this.headerLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headerLbl.Location = new System.Drawing.Point(332, 26);
            this.headerLbl.Name = "headerLbl";
            this.headerLbl.Size = new System.Drawing.Size(88, 29);
            this.headerLbl.TabIndex = 12;
            this.headerLbl.Text = "LOGIN ";
            // 
            // loginGrp
            // 
            this.loginGrp.BackColor = System.Drawing.Color.Gainsboro;
            this.loginGrp.Controls.Add(this.regLbl);
            this.loginGrp.Controls.Add(this.loginBtn);
            this.loginGrp.Location = new System.Drawing.Point(164, 561);
            this.loginGrp.Name = "loginGrp";
            this.loginGrp.Size = new System.Drawing.Size(410, 100);
            this.loginGrp.TabIndex = 14;
            this.loginGrp.TabStop = false;
            // 
            // regLbl
            // 
            this.regLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regLbl.Location = new System.Drawing.Point(110, 16);
            this.regLbl.Name = "regLbl";
            this.regLbl.Size = new System.Drawing.Size(209, 27);
            this.regLbl.TabIndex = 21;
            this.regLbl.Text = "ALREADY HAVE AN ACCOUNT?";
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.Color.Red;
            this.loginBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginBtn.Location = new System.Drawing.Point(113, 58);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(158, 36);
            this.loginBtn.TabIndex = 20;
            this.loginBtn.Text = "LOGIN";
            this.loginBtn.UseVisualStyleBackColor = false;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // txtCellNo
            // 
            this.txtCellNo.Location = new System.Drawing.Point(220, 261);
            this.txtCellNo.Name = "txtCellNo";
            this.txtCellNo.Size = new System.Drawing.Size(134, 20);
            this.txtCellNo.TabIndex = 20;
            // 
            // cellNoLbl
            // 
            this.cellNoLbl.AutoSize = true;
            this.cellNoLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cellNoLbl.Location = new System.Drawing.Point(38, 262);
            this.cellNoLbl.Name = "cellNoLbl";
            this.cellNoLbl.Size = new System.Drawing.Size(138, 16);
            this.cellNoLbl.TabIndex = 19;
            this.cellNoLbl.Text = "CELLPHONE NUMBER:";
            // 
            // registerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(798, 722);
            this.Controls.Add(this.loginGrp);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.deleteGrp);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.headerLbl);
            this.Name = "registerPage";
            this.Text = "registerPage";
            this.deleteGrp.ResumeLayout(false);
            this.deleteGrp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.loginGrp.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.GroupBox deleteGrp;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lNameLbl;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label fNameLbl;
        private System.Windows.Forms.Button registerBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label headerLbl;
        private System.Windows.Forms.TextBox idNotxtBox;
        private System.Windows.Forms.Label emailLbl;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label idNoLbl;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label confirmPassLbl;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label confirmEmailLbl;
        private System.Windows.Forms.TextBox txtConfirmEmail;
        private System.Windows.Forms.Label passLbl;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label usernameLbl;
        private System.Windows.Forms.GroupBox loginGrp;
        private System.Windows.Forms.Label regLbl;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.TextBox txtCellNo;
        private System.Windows.Forms.Label cellNoLbl;
    }
}