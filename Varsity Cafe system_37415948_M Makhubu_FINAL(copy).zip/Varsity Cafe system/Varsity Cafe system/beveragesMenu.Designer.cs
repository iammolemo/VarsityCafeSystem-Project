﻿
namespace Varsity_cafe_system
{
    partial class beveragesMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(beveragesMenu));
            this.label8 = new System.Windows.Forms.Label();
            this.hotBevLbl = new System.Windows.Forms.Label();
            this.cuppacBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.coffBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.fantsOBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.hotChocBtn = new System.Windows.Forms.Button();
            this.spriteBtn = new System.Windows.Forms.Button();
            this.cokeBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.logoPicBx = new System.Windows.Forms.PictureBox();
            this.menuHearderLbl = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.strawberryMilkBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.blueMilkBtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.appleJBtn = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.lemonBtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(207, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 16);
            this.label8.TabIndex = 13;
            this.label8.Text = "COLD BEVERAGES";
            // 
            // hotBevLbl
            // 
            this.hotBevLbl.AutoSize = true;
            this.hotBevLbl.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotBevLbl.Location = new System.Drawing.Point(190, 397);
            this.hotBevLbl.Name = "hotBevLbl";
            this.hotBevLbl.Size = new System.Drawing.Size(105, 16);
            this.hotBevLbl.TabIndex = 12;
            this.hotBevLbl.Text = "HOT BEVERAGES";
            // 
            // cuppacBtn
            // 
            this.cuppacBtn.BackColor = System.Drawing.Color.Red;
            this.cuppacBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cuppacBtn.Location = new System.Drawing.Point(349, 492);
            this.cuppacBtn.Name = "cuppacBtn";
            this.cuppacBtn.Size = new System.Drawing.Size(121, 35);
            this.cuppacBtn.TabIndex = 11;
            this.cuppacBtn.Text = "R25";
            this.cuppacBtn.UseVisualStyleBackColor = false;
            this.cuppacBtn.Click += new System.EventHandler(this.cuppacBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 501);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "CUPPACINNO";
            // 
            // coffBtn
            // 
            this.coffBtn.BackColor = System.Drawing.Color.Red;
            this.coffBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coffBtn.Location = new System.Drawing.Point(349, 446);
            this.coffBtn.Name = "coffBtn";
            this.coffBtn.Size = new System.Drawing.Size(121, 35);
            this.coffBtn.TabIndex = 9;
            this.coffBtn.Text = "R20";
            this.coffBtn.UseVisualStyleBackColor = false;
            this.coffBtn.Click += new System.EventHandler(this.coffBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 455);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "COFFEE";
            // 
            // fantsOBtn
            // 
            this.fantsOBtn.BackColor = System.Drawing.Color.Red;
            this.fantsOBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fantsOBtn.Location = new System.Drawing.Point(353, 106);
            this.fantsOBtn.Name = "fantsOBtn";
            this.fantsOBtn.Size = new System.Drawing.Size(121, 35);
            this.fantsOBtn.TabIndex = 7;
            this.fantsOBtn.Text = "R22";
            this.fantsOBtn.UseVisualStyleBackColor = false;
            this.fantsOBtn.Click += new System.EventHandler(this.fantsOBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "FANTA ORANGE";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.lemonBtn);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.appleJBtn);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.blueMilkBtn);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.strawberryMilkBtn);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.hotBevLbl);
            this.groupBox1.Controls.Add(this.cuppacBtn);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.coffBtn);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.fantsOBtn);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.hotChocBtn);
            this.groupBox1.Controls.Add(this.spriteBtn);
            this.groupBox1.Controls.Add(this.cokeBtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(139, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(515, 594);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // hotChocBtn
            // 
            this.hotChocBtn.BackColor = System.Drawing.Color.Red;
            this.hotChocBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hotChocBtn.Location = new System.Drawing.Point(349, 533);
            this.hotChocBtn.Name = "hotChocBtn";
            this.hotChocBtn.Size = new System.Drawing.Size(121, 38);
            this.hotChocBtn.TabIndex = 5;
            this.hotChocBtn.Text = "R30";
            this.hotChocBtn.UseVisualStyleBackColor = false;
            this.hotChocBtn.Click += new System.EventHandler(this.hotChocBtn_Click);
            // 
            // spriteBtn
            // 
            this.spriteBtn.BackColor = System.Drawing.Color.Red;
            this.spriteBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spriteBtn.Location = new System.Drawing.Point(353, 156);
            this.spriteBtn.Name = "spriteBtn";
            this.spriteBtn.Size = new System.Drawing.Size(121, 35);
            this.spriteBtn.TabIndex = 4;
            this.spriteBtn.Text = "R18";
            this.spriteBtn.UseVisualStyleBackColor = false;
            this.spriteBtn.Click += new System.EventHandler(this.spriteBtn_Click);
            // 
            // cokeBtn
            // 
            this.cokeBtn.BackColor = System.Drawing.Color.Red;
            this.cokeBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cokeBtn.Location = new System.Drawing.Point(353, 55);
            this.cokeBtn.Name = "cokeBtn";
            this.cokeBtn.Size = new System.Drawing.Size(121, 35);
            this.cokeBtn.TabIndex = 3;
            this.cokeBtn.Text = "R20";
            this.cokeBtn.UseVisualStyleBackColor = false;
            this.cokeBtn.Click += new System.EventHandler(this.sweetChilliBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 544);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "HOT CHOCOLATE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "SPRITE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "COCA COLA";
            // 
            // logoPicBx
            // 
            this.logoPicBx.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBx.Image")));
            this.logoPicBx.Location = new System.Drawing.Point(749, -23);
            this.logoPicBx.Name = "logoPicBx";
            this.logoPicBx.Size = new System.Drawing.Size(70, 44);
            this.logoPicBx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBx.TabIndex = 8;
            this.logoPicBx.TabStop = false;
            // 
            // menuHearderLbl
            // 
            this.menuHearderLbl.AutoSize = true;
            this.menuHearderLbl.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuHearderLbl.Location = new System.Drawing.Point(208, 3);
            this.menuHearderLbl.Name = "menuHearderLbl";
            this.menuHearderLbl.Size = new System.Drawing.Size(385, 29);
            this.menuHearderLbl.TabIndex = 11;
            this.menuHearderLbl.Text = "WRAPS AND QUESADILLAS MENU";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Red;
            this.backBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.Location = new System.Drawing.Point(12, 646);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(195, 39);
            this.backBtn.TabIndex = 10;
            this.backBtn.Text = "RETURN TO PREVIOUS PAGE";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // strawberryMilkBtn
            // 
            this.strawberryMilkBtn.BackColor = System.Drawing.Color.Red;
            this.strawberryMilkBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strawberryMilkBtn.Location = new System.Drawing.Point(353, 290);
            this.strawberryMilkBtn.Name = "strawberryMilkBtn";
            this.strawberryMilkBtn.Size = new System.Drawing.Size(121, 35);
            this.strawberryMilkBtn.TabIndex = 15;
            this.strawberryMilkBtn.Text = "R37";
            this.strawberryMilkBtn.UseVisualStyleBackColor = false;
            this.strawberryMilkBtn.Click += new System.EventHandler(this.strawberryMilkBtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 342);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "BLUEBERRY MILKSHAKE";
            // 
            // blueMilkBtn
            // 
            this.blueMilkBtn.BackColor = System.Drawing.Color.Red;
            this.blueMilkBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blueMilkBtn.Location = new System.Drawing.Point(353, 333);
            this.blueMilkBtn.Name = "blueMilkBtn";
            this.blueMilkBtn.Size = new System.Drawing.Size(121, 35);
            this.blueMilkBtn.TabIndex = 17;
            this.blueMilkBtn.Text = "R37";
            this.blueMilkBtn.UseVisualStyleBackColor = false;
            this.blueMilkBtn.Click += new System.EventHandler(this.blueMilkBtn_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "LEMON TWIST";
            // 
            // appleJBtn
            // 
            this.appleJBtn.BackColor = System.Drawing.Color.Red;
            this.appleJBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appleJBtn.Location = new System.Drawing.Point(353, 245);
            this.appleJBtn.Name = "appleJBtn";
            this.appleJBtn.Size = new System.Drawing.Size(121, 35);
            this.appleJBtn.TabIndex = 19;
            this.appleJBtn.Text = "R35";
            this.appleJBtn.UseVisualStyleBackColor = false;
            this.appleJBtn.Click += new System.EventHandler(this.appleJBtn_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(25, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "STRAWBERRY MILKSHAKE";
            // 
            // lemonBtn
            // 
            this.lemonBtn.BackColor = System.Drawing.Color.Red;
            this.lemonBtn.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lemonBtn.Location = new System.Drawing.Point(353, 199);
            this.lemonBtn.Name = "lemonBtn";
            this.lemonBtn.Size = new System.Drawing.Size(121, 35);
            this.lemonBtn.TabIndex = 21;
            this.lemonBtn.Text = "R22";
            this.lemonBtn.UseVisualStyleBackColor = false;
            this.lemonBtn.Click += new System.EventHandler(this.lemonBtn_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(25, 254);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "APPLE JUICE";
            // 
            // beveragesMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(899, 697);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.logoPicBx);
            this.Controls.Add(this.menuHearderLbl);
            this.Controls.Add(this.backBtn);
            this.Name = "beveragesMenu";
            this.Text = "beveragesMenu";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBx)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label hotBevLbl;
        private System.Windows.Forms.Button cuppacBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button coffBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button fantsOBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button lemonBtn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button appleJBtn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button blueMilkBtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button strawberryMilkBtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button hotChocBtn;
        private System.Windows.Forms.Button spriteBtn;
        private System.Windows.Forms.Button cokeBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox logoPicBx;
        private System.Windows.Forms.Label menuHearderLbl;
        private System.Windows.Forms.Button backBtn;
    }
}